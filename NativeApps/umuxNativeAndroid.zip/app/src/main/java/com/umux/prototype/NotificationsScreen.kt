package com.umux.prototype

import android.view.HapticFeedbackConstants
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MarkEmailRead
import androidx.compose.material.icons.filled.MarkEmailUnread
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.RemoveCircle
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberSwipeToDismissBoxState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.util.UUID

/**
 * Full NotificationsScreen replacing the placeholder stub.
 * Implements M3 segmented filter (All / Unread), swipe-to-delete with undo Snackbar,
 * Edit mode, long-press menu, and navigation to NotificationDetailScreen.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationsScreen(
    viewModel: UmuxViewModel,
    onNavigateToNotification: (UUID) -> Unit
) {
    val view = LocalView.current
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    fun triggerLightHaptic() {
        view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
    }

    var isEditMode by remember { mutableStateOf(false) }
    var selectedSegment by remember { mutableIntStateOf(0) } // 0: All, 1: Unread

    val filteredNotifications = remember(viewModel.notifications.toList(), selectedSegment) {
        if (selectedSegment == 1) {
            viewModel.notifications.filter { it.isUnread }
        } else {
            viewModel.notifications
        }
    }

    Scaffold(
        containerColor = UmuxPalette.Background,
        snackbarHost = {
            SnackbarHost(
                hostState = snackbarHostState,
                modifier = Modifier.padding(bottom = 76.dp)
            ) { data ->
                Snackbar(
                    snackbarData = data,
                    containerColor = UmuxPalette.Card,
                    contentColor = UmuxPalette.TextPrimary,
                    actionColor = UmuxPalette.AccentBright,
                    shape = RoundedCornerShape(10.dp)
                )
            }
        },
        topBar = {
            CenterAlignedTopAppBar(
                title = { UmuxLogo() },
                actions = {
                    TextButton(
                        onClick = {
                            triggerLightHaptic()
                            isEditMode = !isEditMode
                        }
                    ) {
                        AnimatedContent(targetState = isEditMode, label = "edit_mode_text") { editing ->
                            Text(
                                text = if (editing) "Done" else "Edit",
                                color = UmuxPalette.AccentBright,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = UmuxPalette.Background,
                    titleContentColor = UmuxPalette.TextPrimary
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Segmented Filter: "All" / "Unread"
            val segments = listOf("All", "Unread")
            SingleChoiceSegmentedButtonRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                segments.forEachIndexed { index, label ->
                    SegmentedButton(
                        shape = SegmentedButtonDefaults.itemShape(index = index, count = segments.size),
                        onClick = {
                            triggerLightHaptic()
                            selectedSegment = index
                        },
                        selected = selectedSegment == index,
                        colors = SegmentedButtonDefaults.colors(
                            activeContainerColor = UmuxPalette.Card,
                            activeContentColor = UmuxPalette.TextPrimary,
                            inactiveContainerColor = Color.Transparent,
                            inactiveContentColor = UmuxPalette.TextSecondary,
                            activeBorderColor = UmuxPalette.Separator,
                            inactiveBorderColor = UmuxPalette.Separator
                        )
                    ) {
                        Text(text = label, fontSize = 14.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            if (filteredNotifications.isEmpty()) {
                // Centered empty state: bell-off icon TextTertiary + "You're all caught up" 15sp medium TextSecondary
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.NotificationsOff,
                            contentDescription = null,
                            tint = UmuxPalette.TextTertiary,
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "You're all caught up",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium,
                            color = UmuxPalette.TextSecondary
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(
                        items = filteredNotifications,
                        key = { it.id }
                    ) { notif ->
                        val dismissState = rememberSwipeToDismissBoxState(
                            confirmValueChange = { value ->
                                if (value == SwipeToDismissBoxValue.EndToStart) {
                                    val originalIndex = viewModel.notifications.indexOfFirst { it.id == notif.id }
                                    triggerLightHaptic()
                                    viewModel.removeNotification(notif.id)
                                    coroutineScope.launch {
                                        val result = snackbarHostState.showSnackbar(
                                            message = "Notification deleted",
                                            actionLabel = "Undo",
                                            duration = SnackbarDuration.Short
                                        )
                                        if (result == SnackbarResult.ActionPerformed) {
                                            viewModel.restoreNotification(notif, originalIndex)
                                        }
                                    }
                                    true
                                } else {
                                    false
                                }
                            }
                        )

                        SwipeToDismissBox(
                            state = dismissState,
                            enableDismissFromStartToEnd = false,
                            enableDismissFromEndToStart = !isEditMode,
                            backgroundContent = {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(UmuxPalette.Destructive, shape = UmuxCardShape)
                                        .padding(horizontal = 20.dp),
                                    contentAlignment = Alignment.CenterEnd
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Delete",
                                        tint = Color.White
                                    )
                                }
                            },
                            content = {
                                NotificationItemCard(
                                    notification = notif,
                                    isEditMode = isEditMode,
                                    onClick = {
                                        if (!isEditMode) {
                                            triggerLightHaptic()
                                            onNavigateToNotification(notif.id)
                                        }
                                    },
                                    onDelete = {
                                        val originalIndex = viewModel.notifications.indexOfFirst { it.id == notif.id }
                                        triggerLightHaptic()
                                        viewModel.removeNotification(notif.id)
                                        coroutineScope.launch {
                                            val result = snackbarHostState.showSnackbar(
                                                message = "Notification deleted",
                                                actionLabel = "Undo",
                                                duration = SnackbarDuration.Short
                                            )
                                            if (result == SnackbarResult.ActionPerformed) {
                                                viewModel.restoreNotification(notif, originalIndex)
                                            }
                                        }
                                    },
                                    onToggleRead = {
                                        triggerLightHaptic()
                                        if (notif.isUnread) {
                                            viewModel.markRead(notif.id)
                                        } else {
                                            viewModel.markUnread(notif.id)
                                        }
                                    }
                                )
                            }
                        )
                    }

                    item(key = "bottom_spacer") {
                        Spacer(modifier = Modifier.height(80.dp))
                    }
                }
            }
        }
    }
}

/**
 * Single card row for a notification with edit mode minus-button,
 * unread indicator, chevron, and long-press menu.
 */
@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
@Composable
private fun NotificationItemCard(
    notification: UmuxNotification,
    isEditMode: Boolean,
    onClick: () -> Unit,
    onDelete: () -> Unit,
    onToggleRead: () -> Unit
) {
    var menuExpanded by remember { mutableStateOf(false) }
    val view = LocalView.current

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = UmuxCardShape,
        colors = umuxCardColors(),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .combinedClickable(
                    onClick = onClick,
                    onLongClick = {
                        if (!isEditMode) {
                            view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                            menuExpanded = true
                        }
                    }
                )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Edit mode leading minus-circle button
                AnimatedVisibility(
                    visible = isEditMode,
                    enter = expandHorizontally() + fadeIn(),
                    exit = shrinkHorizontally() + fadeOut()
                ) {
                    Row {
                        IconButton(
                            onClick = onDelete,
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.RemoveCircle,
                                contentDescription = "Delete notification",
                                tint = UmuxPalette.Destructive,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                    }
                }

                // Workspace name 17sp semibold white, message 15sp TextSecondary below
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    Text(
                        text = notification.workspace,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = UmuxPalette.TextPrimary
                    )
                    Text(
                        text = notification.message,
                        fontSize = 15.sp,
                        color = UmuxPalette.TextSecondary
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                // Trailing: 7dp AccentBright dot when unread + chevron-right TextTertiary
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (notification.isUnread) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .background(UmuxPalette.AccentBright, CircleShape)
                        )
                    }
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                        contentDescription = null,
                        tint = UmuxPalette.TextTertiary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            // Long-press Context Menu
            DropdownMenu(
                expanded = menuExpanded,
                onDismissRequest = { menuExpanded = false },
                modifier = Modifier.background(UmuxPalette.Card)
            ) {
                DropdownMenuItem(
                    text = {
                        Text(
                            text = if (notification.isUnread) "Mark Read" else "Mark Unread",
                            color = UmuxPalette.TextPrimary
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = if (notification.isUnread) Icons.Default.MarkEmailRead else Icons.Default.MarkEmailUnread,
                            contentDescription = null,
                            tint = UmuxPalette.TextSecondary
                        )
                    },
                    onClick = {
                        menuExpanded = false
                        onToggleRead()
                    }
                )
                DropdownMenuItem(
                    text = {
                        Text(
                            text = "Delete",
                            color = UmuxPalette.Destructive
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = null,
                            tint = UmuxPalette.Destructive
                        )
                    },
                    onClick = {
                        menuExpanded = false
                        onDelete()
                    }
                )
            }
        }
    }
}

/**
 * Route "notification/{id}" Detail screen.
 * Standard TopAppBar with back arrow, inline title = notification.workspace.
 * Content: Card with small overline label "MESSAGE" (11sp semibold, letter spacing 1sp, TextTertiary)
 * above message text 17sp white; then reusable PlaceholderCard with terminal icon.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationDetailScreen(
    notificationId: UUID?,
    viewModel: UmuxViewModel,
    onBack: () -> Unit
) {
    val view = LocalView.current
    val notif = viewModel.notifications.find { it.id == notificationId }

    Scaffold(
        containerColor = UmuxPalette.Background,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = notif?.workspace ?: "Notification",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = UmuxPalette.TextPrimary
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = {
                            view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                            onBack()
                        }
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = UmuxPalette.TextPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = UmuxPalette.Background,
                    titleContentColor = UmuxPalette.TextPrimary
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Card with "MESSAGE" overline and message text
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = UmuxCardShape,
                colors = umuxCardColors(),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "MESSAGE",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 1.sp,
                        color = UmuxPalette.TextTertiary
                    )
                    Text(
                        text = notif?.message ?: "No message content",
                        fontSize = 17.sp,
                        color = UmuxPalette.TextPrimary,
                        lineHeight = 24.sp
                    )
                }
            }

            // Reusable PlaceholderCard with terminal icon
            PlaceholderCard(
                icon = Icons.Default.Terminal,
                text = "Tap through to the agent panel here once umux Bridge is connected."
            )
        }
    }
}
