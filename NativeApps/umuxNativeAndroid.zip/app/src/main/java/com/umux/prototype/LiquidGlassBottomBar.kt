package com.umux.prototype

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Liquid Glass floating pill bottom navigation bar.
 * Matches the frosted glass aesthetic:
 * - Floating capsule with translucent dark acrylic background and frosted top border.
 * - Active tab highlighted by a soft translucent pill bubble.
 * - Active icon & label in brand green (#167C51).
 * - Inactive icons in solid crisp white and labels in platinum off-white.
 */
@Composable
fun LiquidGlassBottomBar(
    currentRoute: String?,
    unreadNotificationsCount: Int,
    onNavigateHome: () -> Unit,
    onNavigateNotifications: () -> Unit,
    onNavigateSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val homeSelected = currentRoute == UmuxRoutes.HOME || currentRoute?.startsWith("workspace/") == true
    val notifSelected = currentRoute == UmuxRoutes.NOTIFICATIONS || currentRoute?.startsWith("notification/") == true
    val settingsSelected = currentRoute == UmuxRoutes.SETTINGS

    Box(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 24.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            modifier = Modifier
                .widthIn(max = 380.dp)
                .fillMaxWidth()
                .height(64.dp)
                .shadow(
                    elevation = 20.dp,
                    shape = CircleShape,
                    spotColor = Color.Black.copy(alpha = 0.75f),
                    ambientColor = Color.Black.copy(alpha = 0.45f)
                ),
            shape = CircleShape,
            color = Color.Transparent,
            border = BorderStroke(
                1.dp,
                Brush.verticalGradient(
                    listOf(
                        Color(0x4DFFFFFF), // soft frosted top reflection
                        Color(0x18FFFFFF)  // subtle bottom sheen
                    )
                )
            )
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                Color(0xD9202026), // dark liquid glass top
                                Color(0xEB16161B)  // dark liquid glass bottom
                            )
                        )
                    )
                    .padding(horizontal = 6.dp, vertical = 5.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    LiquidGlassTabItem(
                        selected = homeSelected,
                        label = "Home",
                        icon = Icons.Filled.Home,
                        testTag = "nav_home",
                        onClick = onNavigateHome,
                        modifier = Modifier.weight(1f)
                    )

                    LiquidGlassTabItem(
                        selected = notifSelected,
                        label = "Notifications",
                        icon = Icons.Filled.Notifications,
                        badgeCount = unreadNotificationsCount,
                        testTag = "nav_notifications",
                        onClick = onNavigateNotifications,
                        modifier = Modifier.weight(1f)
                    )

                    LiquidGlassTabItem(
                        selected = settingsSelected,
                        label = "Settings",
                        icon = Icons.Filled.Settings,
                        testTag = "nav_settings",
                        onClick = onNavigateSettings,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
private fun LiquidGlassTabItem(
    selected: Boolean,
    label: String,
    icon: ImageVector,
    testTag: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    badgeCount: Int = 0
) {
    // Brand green active tint (#167C51) & crisp white for unselected
    val activeTint = Color(0xFF167C51)
    val inactiveIconTint = Color(0xFFFFFFFF)
    val inactiveLabelTint = Color(0xFFD0D0D6)

    val contentColor by animateColorAsState(
        targetValue = if (selected) activeTint else inactiveIconTint,
        animationSpec = tween(durationMillis = 100),
        label = "tabContentColor"
    )

    val labelColor by animateColorAsState(
        targetValue = if (selected) activeTint else inactiveLabelTint,
        animationSpec = tween(durationMillis = 100),
        label = "tabLabelColor"
    )

    val bubbleAlpha by animateColorAsState(
        targetValue = if (selected) Color(0x14FFFFFF) else Color.Transparent,
        animationSpec = tween(durationMillis = 100),
        label = "bubbleAlpha"
    )

    val itemShape = RoundedCornerShape(26.dp)

    Box(
        modifier = modifier
            .fillMaxHeight()
            .clip(itemShape)
            .background(bubbleAlpha)
            .then(
                if (selected) {
                    Modifier.border(
                        BorderStroke(
                            0.75.dp,
                            Brush.verticalGradient(
                                listOf(
                                    Color(0x24FFFFFF),
                                    Color(0x0EFFFFFF)
                                )
                            )
                        ),
                        itemShape
                    )
                } else Modifier
            )
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple(bounded = true, color = activeTint),
                onClick = onClick
            )
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            BadgedBox(
                badge = {
                    if (badgeCount > 0) {
                        Badge(
                            containerColor = Color(0xFFFF453A),
                            contentColor = Color.White
                        ) {
                            Text(
                                text = badgeCount.toString(),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = contentColor,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = label,
                color = labelColor,
                fontSize = 11.sp,
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                letterSpacing = 0.2.sp
            )
        }
    }
}
