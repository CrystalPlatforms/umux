package com.umux.prototype

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.UUID

private data class AgentMetadata(
    val tabName: String,
    val folder: String,
    val lastSignalAt: Long
)

class UmuxViewModel : ViewModel() {

    // Sync state for floating pill toast
    var isSyncing by mutableStateOf(false)
        private set

    private var syncJob: Job? = null

    /**
     * Triggers the "Syncing..." floating pill overlay for ~2 seconds.
     * Rapid consecutive mutations restart the 2s timer instead of stacking.
     */
    fun triggerSync() {
        syncJob?.cancel()
        isSyncing = true
        syncJob = viewModelScope.launch {
            delay(2000)
            isSyncing = false
        }
    }

    // Devices
    val devices = listOf("MacBook Pro", "Ubuntu Dev", "ThinkPad")
    var selectedDevice by mutableStateOf("MacBook Pro")

    // Hidden per-workspace agent metadata
    private val now = System.currentTimeMillis()
    private val agentMetadata = mutableMapOf(
        "umux" to AgentMetadata(
            tabName = "claude",
            folder = "Documents/umux",
            lastSignalAt = now - 2 * 60 * 1000L
        ),
        "auditmos" to AgentMetadata(
            tabName = "codex",
            folder = "Documents/auditmos",
            lastSignalAt = now - 14 * 60 * 1000L
        )
    )

    // Viewed agents set (for tracking isUnread)
    private val viewedAgentWorkspaceIds = mutableStateListOf<UUID>()

    // Workspaces
    val workspaces = mutableStateListOf<Workspace>()

    // Workspace Groups
    val workspaceGroups = mutableStateListOf<WorkspaceGroup>()

    // Notifications
    val notifications = mutableStateListOf<UmuxNotification>()

    // Counters for auto-naming
    private var workspaceCounter = 1
    private var groupCounter = 1

    init {
        seedInitialData()
    }

    private fun seedInitialData() {
        // Workspaces: umux (Working), auditmos (NeedsAttention), Test workspace (Idle), Test workspace 2 (Idle)
        workspaces.add(Workspace(name = "umux", status = AgentStatus.Working))
        workspaces.add(Workspace(name = "auditmos", status = AgentStatus.NeedsAttention))
        workspaces.add(Workspace(name = "Test workspace", status = AgentStatus.Idle))
        workspaces.add(Workspace(name = "Test workspace 2", status = AgentStatus.Idle))

        // Notifications
        notifications.add(
            UmuxNotification(
                workspace = "umux",
                message = "Test notification",
                isUnread = true
            )
        )
        notifications.add(
            UmuxNotification(
                workspace = "auditmos",
                message = "Test notification 2",
                isUnread = true
            )
        )

        // Then "Test notification 3" … "Test notification 15"
        // alternating workspace "Test workspace" (odd) / "Test workspace 2" (even),
        // unread only for 3 and 4
        for (i in 3..15) {
            val wsName = if (i % 2 != 0) "Test workspace" else "Test workspace 2"
            val unread = (i == 3 || i == 4)
            notifications.add(
                UmuxNotification(
                    workspace = wsName,
                    message = "Test notification $i",
                    isUnread = unread
                )
            )
        }
    }

    /**
     * Workspaces with status != Idle mapped to AgentRun.
     * Tab and folder are retrieved from agent metadata (defaulting to tab "agent", folder "—").
     * Sorted newest signal first.
     * isUnread = status == NeedsAttention AND not yet marked viewed.
     */
    fun agentRuns(): List<AgentRun> {
        return workspaces
            .filter { it.status != AgentStatus.Idle }
            .map { ws ->
                val meta = agentMetadata[ws.name] ?: AgentMetadata(
                    tabName = "agent",
                    folder = "—",
                    lastSignalAt = now - 60 * 60 * 1000L
                )
                val isUnread = (ws.status == AgentStatus.NeedsAttention) &&
                    !viewedAgentWorkspaceIds.contains(ws.id)

                AgentRun(
                    workspaceName = ws.name,
                    tabName = meta.tabName,
                    folder = meta.folder,
                    status = ws.status,
                    lastSignalAt = meta.lastSignalAt,
                    isUnread = isUnread
                )
            }
            .sortedByDescending { it.lastSignalAt }
    }

    fun markAgentViewed(workspaceId: UUID) {
        if (!viewedAgentWorkspaceIds.contains(workspaceId)) {
            viewedAgentWorkspaceIds.add(workspaceId)
        }
    }

    fun isWorkspaceUnread(workspace: Workspace): Boolean {
        return workspace.status == AgentStatus.NeedsAttention && !viewedAgentWorkspaceIds.contains(workspace.id)
    }

    fun addWorkspace(): Workspace {
        val newWorkspace = Workspace(
            name = "New workspace $workspaceCounter",
            status = AgentStatus.Idle
        )
        workspaceCounter++
        workspaces.add(newWorkspace)
        triggerSync()
        return newWorkspace
    }

    fun addGroup(): WorkspaceGroup {
        val newGroup = WorkspaceGroup(
            name = "New group $groupCounter"
        )
        groupCounter++
        workspaceGroups.add(newGroup)
        triggerSync()
        return newGroup
    }

    fun renameWorkspace(id: UUID, newName: String) {
        val index = workspaces.indexOfFirst { it.id == id }
        if (index != -1) {
            workspaces[index] = workspaces[index].copy(name = newName)
            triggerSync()
        }
    }

    fun renameGroup(id: UUID, newName: String) {
        val index = workspaceGroups.indexOfFirst { it.id == id }
        if (index != -1) {
            workspaceGroups[index] = workspaceGroups[index].copy(name = newName)
            triggerSync()
        }
    }

    fun removeWorkspace(id: UUID) {
        val removed = workspaces.removeAll { it.id == id }
        if (removed) {
            triggerSync()
        }
    }

    fun removeGroup(id: UUID) {
        val removed = workspaceGroups.removeAll { it.id == id }
        if (removed) {
            // Deleting a group does NOT delete its workspaces — they become top-level
            for (i in workspaces.indices) {
                if (workspaces[i].groupId == id) {
                    workspaces[i] = workspaces[i].copy(groupId = null)
                }
            }
            triggerSync()
        }
    }

    fun assignWorkspaceToGroup(workspaceId: UUID, groupId: UUID) {
        val index = workspaces.indexOfFirst { it.id == workspaceId }
        if (index != -1) {
            workspaces[index] = workspaces[index].copy(groupId = groupId)
            triggerSync()
        }
    }

    fun removeWorkspaceFromGroup(workspaceId: UUID) {
        val index = workspaces.indexOfFirst { it.id == workspaceId }
        if (index != -1) {
            workspaces[index] = workspaces[index].copy(groupId = null)
            triggerSync()
        }
    }

    fun removeNotification(id: UUID) {
        val removed = notifications.removeAll { it.id == id }
        if (removed) {
            triggerSync()
        }
    }

    fun restoreNotification(notification: UmuxNotification, index: Int) {
        val safeIndex = index.coerceIn(0, notifications.size)
        notifications.add(safeIndex, notification)
        triggerSync()
    }

    fun markRead(id: UUID) {
        val index = notifications.indexOfFirst { it.id == id }
        if (index != -1 && notifications[index].isUnread) {
            notifications[index] = notifications[index].copy(isUnread = false)
            triggerSync()
        }
    }

    fun markUnread(id: UUID) {
        val index = notifications.indexOfFirst { it.id == id }
        if (index != -1 && !notifications[index].isUnread) {
            notifications[index] = notifications[index].copy(isUnread = true)
            triggerSync()
        }
    }
}
