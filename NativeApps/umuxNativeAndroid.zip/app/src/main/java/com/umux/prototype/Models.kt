package com.umux.prototype

import androidx.compose.ui.graphics.Color
import java.util.UUID

/**
 * Represents the agent execution status of a workspace.
 */
enum class AgentStatus(
    val label: String,
    val shortLabel: String,
    val color: Color
) {
    Working("Agent working", "Working", Color(0xFFE5A54B)),
    NeedsAttention("Needs attention", "Waiting", Color(0xFF4D8DF7)),
    Idle("Idle", "Idle", Color(0xFF98989D))
}

/**
 * Represents a workspace. Null groupId signifies a top-level workspace.
 */
data class Workspace(
    val id: UUID = UUID.randomUUID(),
    val name: String,
    val status: AgentStatus = AgentStatus.Idle,
    val groupId: UUID? = null
)

/**
 * Represents a logical group of workspaces.
 */
data class WorkspaceGroup(
    val id: UUID = UUID.randomUUID(),
    val name: String
)

/**
 * Represents an active run for an agent associated with a workspace.
 */
data class AgentRun(
    val workspaceName: String,
    val tabName: String,
    val folder: String,
    val status: AgentStatus,
    val lastSignalAt: Long,
    val isUnread: Boolean
)

/**
 * Represents an in-app notification.
 */
data class UmuxNotification(
    val id: UUID = UUID.randomUUID(),
    val workspace: String,
    val message: String,
    val isUnread: Boolean
)
