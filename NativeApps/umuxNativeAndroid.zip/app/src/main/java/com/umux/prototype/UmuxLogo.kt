package com.umux.prototype

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.R

/**
 * Reusable UmuxLogo composable.
 * Displays the official umux dot-matrix wordmark logo from R.drawable.umux_logo.
 */
@Composable
fun UmuxLogo(modifier: Modifier = Modifier) {
    Image(
        painter = painterResource(id = R.drawable.umux_logo),
        contentDescription = "umux",
        modifier = modifier.height(40.dp)
    )
}

