package com.umux.prototype

import android.view.HapticFeedbackConstants
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Language
import androidx.compose.material3.Surface
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderOff
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material.icons.outlined.CropSquare
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.material3.pulltorefresh.PullToRefreshDefaults
import androidx.compose.material3.pulltorefresh.rememberPullToRefreshState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.UUID

/**
 * Dialog state container for renaming workspaces or groups.
 */
private sealed class RenameTarget {
    data class WorkspaceTarget(val workspace: Workspace) : RenameTarget()
    data class GroupTarget(val group: WorkspaceGroup) : RenameTarget()
}

/**
 * Full implementation of the Home tab WorkspacesScreen.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorkspacesScreen(
    viewModel: UmuxViewModel,
    onNavigateToWorkspace: (UUID) -> Unit
) {
    val view = LocalView.current
    fun triggerLightHaptic() {
        view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
    }

    var selectedSegment by remember { mutableIntStateOf(0) }
    var deviceMenuExpanded by remember { mutableStateOf(false) }
    var addMenuExpanded by remember { mutableStateOf(false) }

    // Dialog states
    var renameTarget by remember { mutableStateOf<RenameTarget?>(null) }
    var workspaceToMove by remember { mutableStateOf<Workspace?>(null) }

    // Track collapsed group IDs (by default, groups start expanded)
    var collapsedGroupIds by remember { mutableStateOf(setOf<UUID>()) }

    val topLevelWorkspaces = remember(viewModel.workspaces.toList()) {
        viewModel.workspaces.filter { it.groupId == null }
    }
    val groups = viewModel.workspaceGroups

    Scaffold(
        containerColor = UmuxPalette.Background,
        topBar = {
            CenterAlignedTopAppBar(
                title = { UmuxLogo() },
                actions = {
                    // Device switcher action
                    Box {
                        IconButton(
                            onClick = {
                                triggerLightHaptic()
                                deviceMenuExpanded = true
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.SwapVert,
                                contentDescription = "Switch Device",
                                tint = UmuxPalette.TextPrimary
                            )
                        }

                        DropdownMenu(
                            expanded = deviceMenuExpanded,
                            onDismissRequest = { deviceMenuExpanded = false },
                            modifier = Modifier.background(UmuxPalette.Card)
                        ) {
                            viewModel.devices.forEach { device ->
                                val isSelected = device == viewModel.selectedDevice
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = device,
                                            color = if (isSelected) UmuxPalette.AccentBright else UmuxPalette.TextPrimary,
                                            fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
                                        )
                                    },
                                    trailingIcon = if (isSelected) {
                                        {
                                            Icon(
                                                imageVector = Icons.Default.Check,
                                                contentDescription = "Selected",
                                                tint = UmuxPalette.AccentBright
                                            )
                                        }
                                    } else null,
                                    onClick = {
                                        triggerLightHaptic()
                                        viewModel.selectedDevice = device
                                        viewModel.triggerSync()
                                        deviceMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Add action
                    Box {
                        IconButton(
                            onClick = {
                                triggerLightHaptic()
                                addMenuExpanded = true
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "Add",
                                tint = UmuxPalette.TextPrimary
                            )
                        }

                        DropdownMenu(
                            expanded = addMenuExpanded,
                            onDismissRequest = { addMenuExpanded = false },
                            modifier = Modifier.background(UmuxPalette.Card)
                        ) {
                            DropdownMenuItem(
                                text = { Text("New workspace", color = UmuxPalette.TextPrimary) },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Outlined.CropSquare,
                                        contentDescription = null,
                                        tint = UmuxPalette.TextSecondary
                                    )
                                },
                                onClick = {
                                    triggerLightHaptic()
                                    addMenuExpanded = false
                                    viewModel.addWorkspace()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("New group", color = UmuxPalette.TextPrimary) },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.Folder,
                                        contentDescription = null,
                                        tint = UmuxPalette.TextSecondary
                                    )
                                },
                                onClick = {
                                    triggerLightHaptic()
                                    addMenuExpanded = false
                                    viewModel.addGroup()
                                }
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = UmuxPalette.Background,
                    titleContentColor = UmuxPalette.TextPrimary
                )
            )
        }
    ) { innerPadding ->
        val pullToRefreshState = rememberPullToRefreshState()

        PullToRefreshBox(
            isRefreshing = viewModel.isSyncing,
            onRefresh = {
                triggerLightHaptic()
                viewModel.triggerSync()
            },
            state = pullToRefreshState,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            indicator = {
                PullToRefreshDefaults.Indicator(
                    state = pullToRefreshState,
                    isRefreshing = viewModel.isSyncing,
                    modifier = Modifier.align(Alignment.TopCenter),
                    containerColor = UmuxPalette.Card,
                    color = UmuxPalette.AccentBright
                )
            }
        ) {
            Column(
                modifier = Modifier.fillMaxSize()
            ) {
                // Segmented filter row directly under app bar
                val segments = listOf("Local", "Agents", "SSH")
                SingleChoiceSegmentedButtonRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                ) {
                    segments.forEachIndexed { index, label ->
                        SegmentedButton(
                            selected = selectedSegment == index,
                            onClick = {
                                triggerLightHaptic()
                                selectedSegment = index
                            },
                            shape = SegmentedButtonDefaults.itemShape(index = index, count = segments.size),
                            colors = SegmentedButtonDefaults.colors(
                                activeContainerColor = UmuxPalette.Card,
                                activeContentColor = UmuxPalette.TextPrimary,
                                inactiveContainerColor = Color.Transparent,
                                inactiveContentColor = UmuxPalette.TextSecondary,
                                activeBorderColor = UmuxPalette.Separator,
                                inactiveBorderColor = UmuxPalette.Separator
                            )
                        ) {
                            Text(text = label, fontSize = 14.sp)
                        }
                    }
                }


                when (selectedSegment) {
                    0 -> {
                        // Local segment
                        if (topLevelWorkspaces.isEmpty() && groups.isEmpty()) {
                            // Centered empty state
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .verticalScroll(rememberScrollState())
                                    .padding(horizontal = 32.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = null,
                                    tint = UmuxPalette.TextTertiary,
                                    modifier = Modifier.size(36.dp)
                                )
                                Spacer(modifier = Modifier.height(14.dp))
                                Text(
                                    text = "No workspaces yet",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = UmuxPalette.TextSecondary
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Tap + to add a workspace or a group.",
                                    fontSize = 13.sp,
                                    color = UmuxPalette.TextTertiary
                                )
                            }
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            // 1. One card containing all top-level (ungrouped) workspaces as rows
                            if (topLevelWorkspaces.isNotEmpty()) {
                                item(key = "top_level_card") {
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = UmuxCardShape,
                                        colors = umuxCardColors(),
                                        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                                    ) {
                                        Column {
                                            topLevelWorkspaces.forEachIndexed { index, ws ->
                                                WorkspaceRow(
                                                    workspace = ws,
                                                    isUnread = viewModel.isWorkspaceUnread(ws),
                                                    groups = groups,
                                                    onClick = {
                                                        triggerLightHaptic()
                                                        viewModel.markAgentViewed(ws.id)
                                                        onNavigateToWorkspace(ws.id)
                                                    },
                                                    onRename = { renameTarget = RenameTarget.WorkspaceTarget(it) },
                                                    onMoveToGroup = { workspaceToMove = it },
                                                    onRemoveFromGroup = { viewModel.removeWorkspaceFromGroup(it.id) },
                                                    onDelete = {
                                                        triggerLightHaptic()
                                                        viewModel.removeWorkspace(it.id)
                                                    }
                                                )
                                                if (index < topLevelWorkspaces.lastIndex) {
                                                    CardSeparator()
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            // 2. One card per group
                            items(groups, key = { it.id }) { group ->
                                val memberWorkspaces = viewModel.workspaces.filter { it.groupId == group.id }
                                val isExpanded = !collapsedGroupIds.contains(group.id)

                                GroupCard(
                                    group = group,
                                    memberWorkspaces = memberWorkspaces,
                                    isExpanded = isExpanded,
                                    allGroups = groups,
                                    viewModel = viewModel,
                                    onToggleExpand = {
                                        triggerLightHaptic()
                                        collapsedGroupIds = if (isExpanded) {
                                            collapsedGroupIds + group.id
                                        } else {
                                            collapsedGroupIds - group.id
                                        }
                                    },
                                    onRenameGroup = { renameTarget = RenameTarget.GroupTarget(group) },
                                    onDeleteGroup = {
                                        triggerLightHaptic()
                                        viewModel.removeGroup(group.id)
                                    },
                                    onWorkspaceClick = { ws ->
                                        triggerLightHaptic()
                                        viewModel.markAgentViewed(ws.id)
                                        onNavigateToWorkspace(ws.id)
                                    },
                                    onRenameWorkspace = { ws -> renameTarget = RenameTarget.WorkspaceTarget(ws) },
                                    onMoveWorkspaceToGroup = { ws -> workspaceToMove = ws },
                                    onRemoveWorkspaceFromGroup = { ws -> viewModel.removeWorkspaceFromGroup(ws.id) },
                                    onDeleteWorkspace = { ws ->
                                        triggerLightHaptic()
                                        viewModel.removeWorkspace(ws.id)
                                    }
                                )
                            }

                            item(key = "bottom_spacer") {
                                Spacer(modifier = Modifier.height(70.dp))
                            }
                        }
                    }
                }

                1 -> {
                    // Agents segment
                    val agentRuns = remember(viewModel.workspaces.toList(), viewModel.selectedDevice) {
                        viewModel.agentRuns()
                    }
                    if (agentRuns.isEmpty()) {
                        // Empty state: sparkles icon, "No agents running", "Launch an agent in a workspace to see it here."
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState())
                                .padding(horizontal = 32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = null,
                                    tint = UmuxPalette.TextTertiary,
                                    modifier = Modifier.size(36.dp)
                                )
                                Spacer(modifier = Modifier.height(14.dp))
                                Text(
                                    text = "No agents running",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = UmuxPalette.TextSecondary
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Launch an agent in a workspace to see it here.",
                                    fontSize = 13.sp,
                                    color = UmuxPalette.TextTertiary
                                )
                            }
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            item(key = "agents_card") {
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = UmuxCardShape,
                                    colors = umuxCardColors(),
                                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                                ) {
                                    Column {
                                        agentRuns.forEachIndexed { index, run ->
                                            AgentRunRow(run = run)
                                            if (index < agentRuns.lastIndex) {
                                                CardSeparator()
                                            }
                                        }
                                    }
                                }
                            }

                            item(key = "agents_bottom_spacer") {
                                Spacer(modifier = Modifier.height(70.dp))
                            }
                        }
                    }
                }

                2 -> {
                    // SSH segment: Always the empty state
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(horizontal = 32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Language,
                                contentDescription = null,
                                tint = UmuxPalette.TextTertiary,
                                modifier = Modifier.size(36.dp)
                            )
                            Spacer(modifier = Modifier.height(14.dp))
                            Text(
                                text = "No SSH machines yet",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Medium,
                                color = UmuxPalette.TextSecondary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "SSH View arrives with the umux Ecosystem.",
                                fontSize = 13.sp,
                                color = UmuxPalette.TextTertiary
                            )
                        }
                    }
                }
            }
        }
    }
}

    // Rename Dialog
    renameTarget?.let { target ->
        val currentName = when (target) {
            is RenameTarget.WorkspaceTarget -> target.workspace.name
            is RenameTarget.GroupTarget -> target.group.name
        }
        val message = when (target) {
            is RenameTarget.WorkspaceTarget -> "Enter the new workspace name."
            is RenameTarget.GroupTarget -> "Enter the new group name."
        }
        var textValue by remember(target) { mutableStateOf(currentName) }

        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = {
                Text(
                    text = "Rename",
                    style = MaterialTheme.typography.titleMedium,
                    color = UmuxPalette.TextPrimary
                )
            },
            text = {
                Column {
                    Text(
                        text = message,
                        style = MaterialTheme.typography.bodyMedium,
                        color = UmuxPalette.TextSecondary
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = textValue,
                        onValueChange = { textValue = it },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val trimmed = textValue.trim()
                        if (trimmed.isNotEmpty()) {
                            triggerLightHaptic()
                            when (target) {
                                is RenameTarget.WorkspaceTarget -> viewModel.renameWorkspace(target.workspace.id, trimmed)
                                is RenameTarget.GroupTarget -> viewModel.renameGroup(target.group.id, trimmed)
                            }
                        }
                        renameTarget = null
                    }
                ) {
                    Text("Save", color = UmuxPalette.AccentBright)
                }
            },
            dismissButton = {
                TextButton(onClick = { renameTarget = null }) {
                    Text("Cancel", color = UmuxPalette.TextSecondary)
                }
            },
            containerColor = UmuxPalette.Card,
            tonalElevation = 0.dp
        )
    }

    // Move to Group Dialog
    workspaceToMove?.let { ws ->
        AlertDialog(
            onDismissRequest = { workspaceToMove = null },
            title = {
                Text(
                    text = "Move to group…",
                    style = MaterialTheme.typography.titleMedium,
                    color = UmuxPalette.TextPrimary
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (groups.isEmpty()) {
                        Text(
                            text = "No groups available. Create a group first.",
                            color = UmuxPalette.TextSecondary,
                            fontSize = 14.sp
                        )
                    } else {
                        groups.forEach { group ->
                            val isCurrentGroup = ws.groupId == group.id
                            TextButton(
                                onClick = {
                                    triggerLightHaptic()
                                    viewModel.assignWorkspaceToGroup(ws.id, group.id)
                                    workspaceToMove = null
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = group.name,
                                        color = if (isCurrentGroup) UmuxPalette.AccentBright else UmuxPalette.TextPrimary,
                                        fontSize = 15.sp
                                    )
                                    if (isCurrentGroup) {
                                        Text(
                                            text = "Current",
                                            color = UmuxPalette.TextTertiary,
                                            fontSize = 12.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { workspaceToMove = null }) {
                    Text("Cancel", color = UmuxPalette.TextSecondary)
                }
            },
            containerColor = UmuxPalette.Card,
            tonalElevation = 0.dp
        )
    }
}

/**
 * Reusable Workspace Row composable.
 * Used for top-level workspaces and inside expanded group cards.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun WorkspaceRow(
    workspace: Workspace,
    isUnread: Boolean,
    groups: List<WorkspaceGroup>,
    onClick: () -> Unit,
    onRename: (Workspace) -> Unit,
    onMoveToGroup: (Workspace) -> Unit,
    onRemoveFromGroup: (Workspace) -> Unit,
    onDelete: (Workspace) -> Unit,
    modifier: Modifier = Modifier
) {
    val view = LocalView.current
    var menuExpanded by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .combinedClickable(
                onClick = onClick,
                onLongClick = {
                    view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    menuExpanded = true
                }
            )
            .padding(horizontal = 16.dp, vertical = 14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Leading column: workspace name + status row
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = workspace.name,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = UmuxPalette.TextPrimary
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(workspace.status.color, CircleShape)
                    )
                    Text(
                        text = workspace.status.label,
                        fontSize = 15.sp,
                        color = UmuxPalette.TextSecondary
                    )
                }
            }

            // Trailing: unread dot + chevron
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (isUnread) {
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .background(UmuxPalette.AccentBright, CircleShape)
                    )
                }
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                    contentDescription = null,
                    tint = UmuxPalette.TextTertiary,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        // Long-press anchored DropdownMenu
        DropdownMenu(
            expanded = menuExpanded,
            onDismissRequest = { menuExpanded = false },
            modifier = Modifier.background(UmuxPalette.Card)
        ) {
            DropdownMenuItem(
                text = { Text("Rename", color = UmuxPalette.TextPrimary) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = null,
                        tint = UmuxPalette.TextSecondary
                    )
                },
                onClick = {
                    view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    menuExpanded = false
                    onRename(workspace)
                }
            )

            DropdownMenuItem(
                text = { Text("Move to group…", color = UmuxPalette.TextPrimary) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Folder,
                        contentDescription = null,
                        tint = UmuxPalette.TextSecondary
                    )
                },
                onClick = {
                    view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    menuExpanded = false
                    onMoveToGroup(workspace)
                }
            )

            if (workspace.groupId != null) {
                DropdownMenuItem(
                    text = { Text("Remove from group", color = UmuxPalette.TextPrimary) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.FolderOff,
                            contentDescription = null,
                            tint = UmuxPalette.TextSecondary
                        )
                    },
                    onClick = {
                        view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                        menuExpanded = false
                        onRemoveFromGroup(workspace)
                    }
                )
            }

            DropdownMenuItem(
                text = { Text("Delete", color = UmuxPalette.Destructive) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = null,
                        tint = UmuxPalette.Destructive
                    )
                },
                onClick = {
                    view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    menuExpanded = false
                    onDelete(workspace)
                }
            )
        }
    }
}

/**
 * Group card component.
 * Features an expandable header, animated rotation chevron, member count, and long-press menu.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun GroupCard(
    group: WorkspaceGroup,
    memberWorkspaces: List<Workspace>,
    isExpanded: Boolean,
    allGroups: List<WorkspaceGroup>,
    viewModel: UmuxViewModel,
    onToggleExpand: () -> Unit,
    onRenameGroup: () -> Unit,
    onDeleteGroup: () -> Unit,
    onWorkspaceClick: (Workspace) -> Unit,
    onRenameWorkspace: (Workspace) -> Unit,
    onMoveWorkspaceToGroup: (Workspace) -> Unit,
    onRemoveWorkspaceFromGroup: (Workspace) -> Unit,
    onDeleteWorkspace: (Workspace) -> Unit,
    modifier: Modifier = Modifier
) {
    val view = LocalView.current
    var headerMenuExpanded by remember { mutableStateOf(false) }

    val chevronRotation by animateFloatAsState(
        targetValue = if (isExpanded) 180f else 0f,
        label = "GroupChevronRotation"
    )

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = UmuxCardShape,
        colors = umuxCardColors(),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column {
            // Clickable Header Row
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .combinedClickable(
                        onClick = onToggleExpand,
                        onLongClick = {
                            view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                            headerMenuExpanded = true
                        }
                    )
                    .padding(horizontal = 16.dp, vertical = 14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Folder icon: filled when collapsed, outline when expanded
                        Icon(
                            imageVector = if (isExpanded) Icons.Outlined.Folder else Icons.Filled.Folder,
                            contentDescription = null,
                            tint = UmuxPalette.AccentBright,
                            modifier = Modifier.size(20.dp)
                        )

                        Text(
                            text = group.name,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = UmuxPalette.TextPrimary
                        )

                        Text(
                            text = "${memberWorkspaces.size}",
                            fontSize = 13.sp,
                            color = UmuxPalette.TextTertiary
                        )
                    }

                    Icon(
                        imageVector = Icons.Default.KeyboardArrowDown,
                        contentDescription = if (isExpanded) "Collapse" else "Expand",
                        tint = UmuxPalette.TextTertiary,
                        modifier = Modifier
                            .size(20.dp)
                            .rotate(chevronRotation)
                    )
                }

                // Long-press DropdownMenu on Header
                DropdownMenu(
                    expanded = headerMenuExpanded,
                    onDismissRequest = { headerMenuExpanded = false },
                    modifier = Modifier.background(UmuxPalette.Card)
                ) {
                    DropdownMenuItem(
                        text = { Text("Rename", color = UmuxPalette.TextPrimary) },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = null,
                                tint = UmuxPalette.TextSecondary
                            )
                        },
                        onClick = {
                            view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                            headerMenuExpanded = false
                            onRenameGroup()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Delete", color = UmuxPalette.Destructive) },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = null,
                                tint = UmuxPalette.Destructive
                            )
                        },
                        onClick = {
                            view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                            headerMenuExpanded = false
                            onDeleteGroup()
                        }
                    )
                }
            }

            // Expanded content: CardSeparator + member workspace rows
            AnimatedVisibility(
                visible = isExpanded,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Column {
                    if (memberWorkspaces.isNotEmpty()) {
                        CardSeparator()
                        memberWorkspaces.forEachIndexed { index, ws ->
                            WorkspaceRow(
                                workspace = ws,
                                isUnread = viewModel.isWorkspaceUnread(ws),
                                groups = allGroups,
                                onClick = { onWorkspaceClick(ws) },
                                onRename = onRenameWorkspace,
                                onMoveToGroup = onMoveWorkspaceToGroup,
                                onRemoveFromGroup = onRemoveWorkspaceFromGroup,
                                onDelete = onDeleteWorkspace
                            )
                            if (index < memberWorkspaces.lastIndex) {
                                CardSeparator()
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Informational row for an active agent run in the Agents tab.
 * Not clickable, no long-press, no navigation.
 */
@Composable
fun AgentRunRow(
    run: AgentRun,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Leading: small status chip — fully-rounded pill with status color at 15% alpha
        Surface(
            shape = CircleShape,
            color = run.status.color.copy(alpha = 0.15f),
            tonalElevation = 0.dp,
            shadowElevation = 0.dp
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .background(run.status.color, CircleShape)
                )
                Text(
                    text = run.status.shortLabel,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = run.status.color
                )
            }
        }

        Spacer(modifier = Modifier.width(12.dp))

        // Middle column: tabName 17sp semibold white; below it "folder · workspaceName" 14sp TextSecondary, single line, ellipsized
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(
                text = run.tabName,
                fontSize = 17.sp,
                fontWeight = FontWeight.SemiBold,
                color = UmuxPalette.TextPrimary
            )
            Text(
                text = "${run.folder} · ${run.workspaceName}",
                fontSize = 14.sp,
                color = UmuxPalette.TextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        // Trailing: 7dp AccentBright dot when unread
        if (run.isUnread) {
            Spacer(modifier = Modifier.width(8.dp))
            Box(
                modifier = Modifier
                    .size(7.dp)
                    .background(UmuxPalette.AccentBright, CircleShape)
            )
        }
    }
}
