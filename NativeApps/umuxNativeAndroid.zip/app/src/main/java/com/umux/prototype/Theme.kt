package com.umux.prototype

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat

/**
 * Named design tokens for the Umux dark palette.
 */
object UmuxPalette {
    val Background = Color(0xFF050505)
    val Card = Color(0xFF131315)
    val Separator = Color(0xFF262628)
    val Accent = Color(0xFF2F7D52)
    val AccentBright = Color(0xFF45A26B)
    val TextPrimary = Color(0xFFFFFFFF)
    val TextSecondary = Color(0xFF9A9AA0)
    val TextTertiary = Color(0xFF6C6C72)
    val Destructive = Color(0xFFFF5C5C)
}

/**
 * Reusable 0.5dp line in Separator color inset 16dp horizontally.
 * Used between rows inside cards throughout the app.
 */
@Composable
fun CardSeparator(modifier: Modifier = Modifier) {
    HorizontalDivider(
        modifier = modifier.padding(horizontal = 16.dp),
        thickness = 0.5.dp,
        color = UmuxPalette.Separator
    )
}

/**
 * Default card colors for flat dark cards:
 * #131315 on the #050505 background with no elevation.
 */
@Composable
fun umuxCardColors() = CardDefaults.cardColors(
    containerColor = UmuxPalette.Card,
    contentColor = UmuxPalette.TextPrimary
)

val UmuxCardShape = RoundedCornerShape(14.dp)

private val UmuxDarkColorScheme = darkColorScheme(
    primary = UmuxPalette.Accent,
    onPrimary = Color.White,
    primaryContainer = UmuxPalette.Accent,
    onPrimaryContainer = Color.White,
    secondary = UmuxPalette.AccentBright,
    onSecondary = Color.White,
    secondaryContainer = UmuxPalette.Card,
    onSecondaryContainer = UmuxPalette.TextPrimary,
    tertiary = UmuxPalette.AccentBright,
    onTertiary = Color.White,
    background = UmuxPalette.Background,
    onBackground = UmuxPalette.TextPrimary,
    surface = UmuxPalette.Background,
    onSurface = UmuxPalette.TextPrimary,
    surfaceVariant = UmuxPalette.Card,
    onSurfaceVariant = UmuxPalette.TextSecondary,
    outline = UmuxPalette.Separator,
    outlineVariant = UmuxPalette.Separator
)

val UmuxTypography = Typography(
    titleLarge = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.SemiBold,
        fontSize = 20.sp,
        lineHeight = 26.sp,
        color = UmuxPalette.TextPrimary
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Medium,
        fontSize = 16.sp,
        lineHeight = 22.sp,
        color = UmuxPalette.TextPrimary
    ),
    bodyLarge = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Normal,
        fontSize = 15.sp,
        lineHeight = 20.sp,
        color = UmuxPalette.TextPrimary
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 18.sp,
        color = UmuxPalette.TextSecondary
    ),
    bodySmall = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Normal,
        fontSize = 12.sp,
        lineHeight = 16.sp,
        color = UmuxPalette.TextTertiary
    ),
    labelMedium = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Medium,
        fontSize = 12.sp,
        lineHeight = 16.sp,
        color = UmuxPalette.TextSecondary
    )
)

val UmuxShapes = Shapes(
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(18.dp)
)

@Composable
fun UmuxTheme(
    content: @Composable () -> Unit
) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = UmuxPalette.Background.toArgb()
                window.navigationBarColor = UmuxPalette.Background.toArgb()
                val windowInsetsController = WindowCompat.getInsetsController(window, view)
                // Dark theme: white/light icons on dark status/nav bars
                windowInsetsController.isAppearanceLightStatusBars = false
                windowInsetsController.isAppearanceLightNavigationBars = false
            }
        }
    }

    // Force dark theme regardless of system setting
    MaterialTheme(
        colorScheme = UmuxDarkColorScheme,
        typography = UmuxTypography,
        shapes = UmuxShapes,
        content = content
    )
}
