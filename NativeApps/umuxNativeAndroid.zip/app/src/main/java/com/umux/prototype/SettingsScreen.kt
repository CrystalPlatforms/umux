package com.umux.prototype

import android.view.HapticFeedbackConstants
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LargeTopAppBar
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberTopAppBarState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R

/**
 * Reusable official Google "G" four-color brand mark.
 */
@Composable
fun GoogleLogo(modifier: Modifier = Modifier) {
    Icon(
        painter = painterResource(id = R.drawable.ic_brand_google),
        contentDescription = "Google",
        tint = Color.Unspecified,
        modifier = modifier.size(20.dp)
    )
}

/**
 * Reusable official GitHub brand mark in white.
 */
@Composable
fun GitHubLogo(modifier: Modifier = Modifier) {
    Icon(
        painter = painterResource(id = R.drawable.ic_brand_github),
        contentDescription = "GitHub",
        tint = Color.White,
        modifier = modifier.size(20.dp)
    )
}

/**
 * Reusable official Apple brand mark in white.
 */
@Composable
fun AppleLogo(modifier: Modifier = Modifier) {
    Icon(
        painter = painterResource(id = R.drawable.ic_brand_apple),
        contentDescription = "Apple",
        tint = Color.White,
        modifier = modifier.size(20.dp)
    )
}

/**
 * SettingsScreen implementation using Material 3 components exclusively.
 * Includes LargeTopAppBar, official brand vector drawables, sign-in dialog,
 * info cards, and footer.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: UmuxViewModel
) {
    val view = LocalView.current
    val scrollBehavior = TopAppBarDefaults.exitUntilCollapsedScrollBehavior(rememberTopAppBarState())
    var showComingSoonDialog by remember { mutableStateOf(false) }

    fun triggerLightHaptic() {
        view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
    }

    Scaffold(
        modifier = Modifier.nestedScroll(scrollBehavior.nestedScrollConnection),
        containerColor = UmuxPalette.Background,
        topBar = {
            LargeTopAppBar(
                title = {
                    Text(
                        text = "Settings",
                        fontWeight = FontWeight.Bold,
                        color = UmuxPalette.TextPrimary
                    )
                },
                colors = TopAppBarDefaults.largeTopAppBarColors(
                    containerColor = UmuxPalette.Background,
                    scrolledContainerColor = UmuxPalette.Background,
                    titleContentColor = UmuxPalette.TextPrimary
                ),
                scrollBehavior = scrollBehavior
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. One card with three stacked rows separated by CardSeparator — sign-in options
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = UmuxCardShape,
                colors = umuxCardColors(),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
            ) {
                Column {
                    // Continue with Google
                    SignInOptionRow(
                        title = "Continue with Google",
                        logo = { GoogleLogo() },
                        onClick = {
                            triggerLightHaptic()
                            showComingSoonDialog = true
                        }
                    )

                    CardSeparator()

                    // Continue with GitHub
                    SignInOptionRow(
                        title = "Continue with GitHub",
                        logo = { GitHubLogo() },
                        onClick = {
                            triggerLightHaptic()
                            showComingSoonDialog = true
                        }
                    )

                    CardSeparator()

                    // Continue with Apple
                    SignInOptionRow(
                        title = "Continue with Apple",
                        logo = { AppleLogo() },
                        onClick = {
                            triggerLightHaptic()
                            showComingSoonDialog = true
                        }
                    )
                }
            }

            // 2. Two separate info cards: "Paired devices" and "Push notifications"
            InfoCard(
                title = "Paired devices",
                value = "umux Bridge — soon"
            )

            InfoCard(
                title = "Push notifications",
                value = "umux Bridge — soon"
            )

            // 3. Footer centered 12sp TextTertiary with extra top padding
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "umux NativeApp for Android developer prototype",
                fontSize = 12.sp,
                color = UmuxPalette.TextTertiary,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(80.dp))
        }
    }

    // Coming soon dialog for sign-in options
    if (showComingSoonDialog) {
        AlertDialog(
            onDismissRequest = { showComingSoonDialog = false },
            title = {
                Text(
                    text = "Coming soon",
                    fontWeight = FontWeight.SemiBold,
                    color = UmuxPalette.TextPrimary
                )
            },
            text = {
                Text(
                    text = "Sign-in ships with the umux Ecosystem.",
                    color = UmuxPalette.TextSecondary
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        triggerLightHaptic()
                        showComingSoonDialog = false
                    }
                ) {
                    Text(
                        text = "OK",
                        color = UmuxPalette.AccentBright,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            },
            containerColor = UmuxPalette.Card,
            shape = UmuxCardShape
        )
    }
}

/**
 * Row inside the Sign-in options card.
 * Title 16sp medium white + trailing chevron-right TextTertiary, 16dp/15dp padding.
 */
@Composable
private fun SignInOptionRow(
    title: String,
    logo: @Composable () -> Unit,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        logo()
        Spacer(modifier = Modifier.width(14.dp))
        Text(
            text = title,
            fontSize = 16.sp,
            fontWeight = FontWeight.Medium,
            color = UmuxPalette.TextPrimary,
            modifier = Modifier.weight(1f)
        )
        Icon(
            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
            contentDescription = null,
            tint = UmuxPalette.TextTertiary,
            modifier = Modifier.size(20.dp)
        )
    }
}

/**
 * Non-clickable info card.
 * Title 16sp TextSecondary, value 14sp TextTertiary, 16dp/13dp padding.
 */
@Composable
private fun InfoCard(
    title: String,
    value: String
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = UmuxCardShape,
        colors = umuxCardColors(),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = title,
                fontSize = 16.sp,
                color = UmuxPalette.TextSecondary
            )
            Text(
                text = value,
                fontSize = 14.sp,
                color = UmuxPalette.TextTertiary
            )
        }
    }
}
