package com.umux.prototype

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

// Official Google brand palette
val GoogleBlue = Color(0xFF4285F4)
val GoogleRed = Color(0xFFEA4335)
val GoogleYellow = Color(0xFFFBBC05)
val GoogleGreen = Color(0xFF34A853)

/**
 * Authentic Google-style 4-color rotating indeterminate circular progress indicator.
 * Cycles smoothly through Google Blue, Red, Yellow, and Green with an expanding/contracting arc.
 */
@Composable
fun GoogleLoader(
    modifier: Modifier = Modifier,
    size: Dp = 38.dp,
    strokeWidth: Dp = 3.5.dp
) {
    val infiniteTransition = rememberInfiniteTransition(label = "GoogleLoaderTransition")

    // Continuous rotation
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    // Arc sweep: expanding and contracting
    val arcProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = keyframes {
                durationMillis = 2800
                0.0f at 0 with FastOutSlowInEasing
                0.5f at 1400 with FastOutSlowInEasing
                1.0f at 2800
            },
            repeatMode = RepeatMode.Restart
        ),
        label = "arcProgress"
    )

    // Color cycle every 1400ms: Blue -> Red -> Yellow -> Green
    val colorStep by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 4f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 5600, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "colorStep"
    )

    val targetColor = when (colorStep.toInt() % 4) {
        0 -> GoogleBlue
        1 -> GoogleRed
        2 -> GoogleYellow
        else -> GoogleGreen
    }

    val animatedColor by animateColorAsState(
        targetValue = targetColor,
        animationSpec = tween(durationMillis = 350, easing = LinearEasing),
        label = "googleColorAnim"
    )

    Canvas(modifier = modifier.size(size)) {
        val stroke = Stroke(
            width = strokeWidth.toPx(),
            cap = StrokeCap.Round
        )

        val sweepAngle = if (arcProgress < 0.5f) {
            40f + 230f * (arcProgress * 2f)
        } else {
            270f - 230f * ((arcProgress - 0.5f) * 2f)
        }

        val startAngle = rotation + (arcProgress * 360f)

        drawArc(
            color = animatedColor,
            startAngle = startAngle,
            sweepAngle = sweepAngle.coerceIn(30f, 280f),
            useCenter = false,
            style = stroke
        )
    }
}

/**
 * Authentic Google-style 4-color horizontal streaming progress bar.
 * Continuously glides Google Blue, Red, Yellow, Green across the top edge.
 */
@Composable
fun GoogleLinearLoader(
    modifier: Modifier = Modifier,
    height: Dp = 2.5.dp
) {
    val infiniteTransition = rememberInfiniteTransition(label = "GoogleLinearTransition")
    val progress by infiniteTransition.animateFloat(
        initialValue = -0.4f,
        targetValue = 1.4f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1100, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "linearProgress"
    )

    val colorStep by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 4f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 4400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "linearColorStep"
    )

    val activeColor = when (colorStep.toInt() % 4) {
        0 -> GoogleBlue
        1 -> GoogleRed
        2 -> GoogleYellow
        else -> GoogleGreen
    }

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(height)
    ) {
        val width = size.width
        val barHeight = size.height

        val startX = progress * width
        val barLength = width * 0.45f

        drawRect(
            color = activeColor.copy(alpha = 0.85f),
            topLeft = androidx.compose.ui.geometry.Offset(
                x = (startX - barLength).coerceAtLeast(0f),
                y = 0f
            ),
            size = androidx.compose.ui.geometry.Size(
                width = (barLength).coerceAtMost(width),
                height = barHeight
            )
        )
    }
}

@Composable
fun GoogleLoaderOverlay(
    modifier: Modifier = Modifier,
    size: Dp = 38.dp
) {
    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            shape = CircleShape,
            color = UmuxPalette.Card.copy(alpha = 0.92f),
            modifier = Modifier
                .size(60.dp)
                .shadow(elevation = 12.dp, shape = CircleShape),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x22FFFFFF))
        ) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                GoogleLoader(size = size, strokeWidth = 3.5.dp)
            }
        }
    }
}
