package com.umux.prototype

import android.view.HapticFeedbackConstants
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import java.util.UUID

/**
 * Route constants for top-level tabs and detail screens.
 */
object UmuxRoutes {
    const val HOME = "home"
    const val NOTIFICATIONS = "notifications"
    const val SETTINGS = "settings"
    const val WORKSPACE_DETAIL = "workspace/{id}"
    const val NOTIFICATION_DETAIL = "notification/{id}"

    fun workspaceDetail(id: UUID) = "workspace/$id"
    fun notificationDetail(id: UUID) = "notification/$id"
}

@Composable
fun rememberLightHaptic(): () -> Unit {
    val view = LocalView.current
    return remember(view) {
        {
            view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppRoot(
    viewModel: UmuxViewModel,
    navController: NavHostController = rememberNavController()
) {
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route
    val lightHaptic = rememberLightHaptic()

    val unreadNotificationsCount = remember(viewModel.notifications.toList()) {
        viewModel.notifications.count { it.isUnread }
    }

    var isTabLoading by remember { mutableStateOf(false) }

    LaunchedEffect(currentRoute) {
        if (currentRoute != null) {
            isTabLoading = true
            delay(220)
            isTabLoading = false
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = UmuxPalette.Background,
        bottomBar = {
            LiquidGlassBottomBar(
                currentRoute = currentRoute,
                unreadNotificationsCount = unreadNotificationsCount,
                onNavigateHome = {
                    lightHaptic()
                    val homeSelected = currentRoute == UmuxRoutes.HOME || currentRoute?.startsWith("workspace/") == true
                    if (!homeSelected) {
                        navController.navigate(UmuxRoutes.HOME) {
                            popUpTo(navController.graph.findStartDestination().id) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                },
                onNavigateNotifications = {
                    lightHaptic()
                    val notifSelected = currentRoute == UmuxRoutes.NOTIFICATIONS || currentRoute?.startsWith("notification/") == true
                    if (!notifSelected) {
                        navController.navigate(UmuxRoutes.NOTIFICATIONS) {
                            popUpTo(navController.graph.findStartDestination().id) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                },
                onNavigateSettings = {
                    lightHaptic()
                    val settingsSelected = currentRoute == UmuxRoutes.SETTINGS
                    if (!settingsSelected) {
                        navController.navigate(UmuxRoutes.SETTINGS) {
                            popUpTo(navController.graph.findStartDestination().id) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(UmuxPalette.Background)
        ) {
            NavHost(
                navController = navController,
                startDestination = UmuxRoutes.HOME,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                enterTransition = { EnterTransition.None },
                exitTransition = { ExitTransition.None },
                popEnterTransition = { EnterTransition.None },
                popExitTransition = { ExitTransition.None }
            ) {
                composable(UmuxRoutes.HOME) {
                    WorkspacesScreen(
                        viewModel = viewModel,
                        onNavigateToWorkspace = { id ->
                            navController.navigate(UmuxRoutes.workspaceDetail(id))
                        }
                    )
                }

                composable(UmuxRoutes.NOTIFICATIONS) {
                    NotificationsScreen(
                        viewModel = viewModel,
                        onNavigateToNotification = { id ->
                            navController.navigate(UmuxRoutes.notificationDetail(id))
                        }
                    )
                }

                composable(UmuxRoutes.SETTINGS) {
                    SettingsScreen(viewModel = viewModel)
                }

                composable(
                    route = UmuxRoutes.WORKSPACE_DETAIL,
                    arguments = listOf(navArgument("id") { type = NavType.StringType })
                ) { backStackEntry ->
                    val idString = backStackEntry.arguments?.getString("id")
                    val workspaceId = runCatching { UUID.fromString(idString) }.getOrNull()
                    WorkspaceDetailScreen(
                        workspaceId = workspaceId,
                        viewModel = viewModel,
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(
                    route = UmuxRoutes.NOTIFICATION_DETAIL,
                    arguments = listOf(navArgument("id") { type = NavType.StringType })
                ) { backStackEntry ->
                    val idString = backStackEntry.arguments?.getString("id")
                    val notificationId = runCatching { UUID.fromString(idString) }.getOrNull()
                    NotificationDetailScreen(
                        notificationId = notificationId,
                        viewModel = viewModel,
                        onBack = { navController.popBackStack() }
                    )
                }
            }

            // Sleek Google 4-color top progress stream: active on tab switch & syncing
            AnimatedVisibility(
                visible = isTabLoading || viewModel.isSyncing,
                enter = fadeIn(animationSpec = tween(50)),
                exit = fadeOut(animationSpec = tween(140)),
                modifier = Modifier.align(Alignment.TopCenter)
            ) {
                GoogleLinearLoader(height = 3.dp)
            }

            // Sync Toast: small floating capsule floating just above bottom NavigationBar
            AnimatedVisibility(
                visible = viewModel.isSyncing,
                enter = fadeIn(animationSpec = tween(150)) + slideInVertically(animationSpec = tween(200)) { it / 2 },
                exit = fadeOut(animationSpec = tween(150)) + slideOutVertically(animationSpec = tween(200)) { it / 2 },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = innerPadding.calculateBottomPadding() + 16.dp)
            ) {
                Surface(
                    shape = CircleShape,
                    color = UmuxPalette.Card,
                    border = BorderStroke(1.dp, UmuxPalette.Separator),
                    shadowElevation = 0.dp,
                    tonalElevation = 0.dp
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        GoogleLoader(
                            size = 15.dp,
                            strokeWidth = 2.dp
                        )
                        Text(
                            text = "Syncing...",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            color = UmuxPalette.TextPrimary
                        )
                    }
                }
            }
        }
    }
}
