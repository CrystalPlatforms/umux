package com.umux.prototype

import android.view.HapticFeedbackConstants
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.UUID

/**
 * Reusable placeholder card with an icon and centered explanatory text.
 * Used in Workspace Detail and reusable in Notification Detail.
 */
@Composable
fun PlaceholderCard(
    icon: ImageVector,
    text: String,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = UmuxCardShape,
        colors = umuxCardColors(),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = UmuxPalette.TextTertiary,
                modifier = Modifier.size(26.dp)
            )
            Spacer(modifier = Modifier.height(14.dp))
            Text(
                text = text,
                fontSize = 14.sp,
                color = UmuxPalette.TextSecondary,
                textAlign = TextAlign.Center,
                lineHeight = 20.sp
            )
        }
    }
}

/**
 * Workspace Detail Screen (Route "workspace/{id}").
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorkspaceDetailScreen(
    workspaceId: UUID?,
    viewModel: UmuxViewModel,
    onBack: () -> Unit
) {
    val view = LocalView.current
    val workspace = viewModel.workspaces.find { it.id == workspaceId }

    Scaffold(
        containerColor = UmuxPalette.Background,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = workspace?.name ?: "Workspace",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = UmuxPalette.TextPrimary
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = {
                            view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                            onBack()
                        }
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = UmuxPalette.TextPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = UmuxPalette.Background,
                    titleContentColor = UmuxPalette.TextPrimary
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 20.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.Start,
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // 1. Status pill: capsule with the Card color background, 9dp status-color dot + status label 15sp medium TextSecondary, 14dp/9dp padding.
            val status = workspace?.status ?: AgentStatus.Idle
            Surface(
                shape = CircleShape,
                color = UmuxPalette.Card,
                tonalElevation = 0.dp,
                shadowElevation = 0.dp
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(9.dp)
                            .background(status.color, CircleShape)
                    )
                    Text(
                        text = status.label,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium,
                        color = UmuxPalette.TextSecondary
                    )
                }
            }

            // 2. Reusable PlaceholderCard with terminal icon and streaming output message
            PlaceholderCard(
                icon = Icons.Default.Terminal,
                text = "The read-only agent output will stream here once umux Bridge is connected."
            )
        }
    }
}
