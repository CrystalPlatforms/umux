# CLAUDE.md — umux iOS (prototyp PWA jako aplikacja natywna)

## Co to jest

Natywny prototyp iOS (SwiftUI) widoków umux PWA — ekran Workspaces, Notifications, Settings — budowany w Xcode. Wzorowany na mockupie „umux PWA — 01 Workspaces / 02 Notifications" (2026-09-12), ale renderowany **oficjalnymi komponentami Apple**, nie 1:1 z mockupem.

## Decyzja PO (Adam, 2026-09-12) — OFICJALNE KOMPONENTY APPLE

Przechodzimy na **wyłącznie oficjalne komponenty Apple z natywnym Liquid Glass (iOS 26+)**. Obowiązuje zakaz „kombinowania":

- **ZAKAZ** ręcznego rysowania szkła: żadnego własnego `glassEffect` na custom controls, własnych szklanych pigułek/kapsułek, własnych segmentów, własnego dolnego paska, własnych tł „aurora". Filtry to oficjalny `Picker(.segmented)` z samymi napisami (PO decyzja 2026-09-12 — systemowy segment nie pokaże ikony+napisu naraz; wybrano napisy).
- Chrom (nawigacja) = systemowe komponenty, które dostają Liquid Glass automatycznie:
  - `TabView` → systemowy pływający szklany pasek dolny;
  - `NavigationStack` + `.toolbar` → szklane kapsuły na przyciskach paska;
  - `Picker(.segmented)` → standardowy segment;
  - systemowy przycisk Wstecz + `.navigationTitle` na ekranach szczegółów.
- Treść (karty list) = zwykłe ciemne karty (`Theme.card`), bez szkła — wg wytycznych Apple szkło jest dla nawigacji, nie dla treści.
- Próby custom-szkła były i zostały odrzucone przez PO („masakra", „nic nie ma", „połącz z powrotem") — nie wracać do nich.

## Tożsamość wizualna

- Logo: oficjalny PNG `umux-name-trans.png` w `Assets.xcassets/UmuxLogo.imageset` (biały, przezroczysty) — widok `UmuxLogo` (parametr `height`), umieszczony jako `ToolbarItem(placement: .principal)`.
- Akcent: zieleń umux (`AccentColor` w assetach = #2F7D52; `Theme.accent`/`accentBright`), ciemny motyw wymuszony `.preferredColorScheme(.dark)`.
- Dane: wyłącznie demo/mock (listy w `DataStore`), zgodnie z etapem prototypu.

## Zasady pracy w tym projekcie

- **Nie instalować aplikacji nigdzie** (PO, 2026-09-12) — weryfikacja wyłącznie przez kompilację; PO sam uruchamia w Xcode (⌘R).
- **Nie commitować bez zgody PO.**
- Budować przez `/Applications/Xcode-beta.app/Contents/Developer/usr/bin/xcodebuild` (domyślny `xcodebuild` wskazuje na Command Line Tools i pada): `xcodebuild -project umux.xcodeproj -scheme umux -destination 'generic/platform=iOS Simulator' build`.
- Deployment target iOS 27.0; projekt w formacie Xcode „synchronized folders" — nowe pliki Swift zasobów wrzucone do `umux/` są kompilowane automatycznie.
- Powiązane repo desktop: `/Users/panad/Documents/umux` (Tauri; PWA w ekosystemie, PRD `plans/umux-v2.0.0-prd.md` na gałęzi `development`).
- Ścieżka projektu bywa zmieniana przez PO: `/Users/panad/Documents/Xcode /umux` (ze spacją) ↔ `/Users/panad/Documents/Xcode/umux` — zawsze bierz aktualną ścieżkę ze środowiska sesji, nie z pamięci.

## Lekcje z sesji 2026-09-12 — błędy i rozwiązania (czytaj NAJPIERW przy problemach)

**Błędy kompilacji, które już padły i ich lekarstwa:**
- `tool 'xcodebuild' requires Xcode, but active developer directory is CommandLineTools` → wołaj binarkę z pełną ścieżką `/Applications/Xcode-beta.app/Contents/Developer/usr/bin/xcodebuild` (simctl analogicznie: `.../usr/bin/simctl`).
- `type does not conform to ObservableObject` + `static subscript ... missing import of Combine` → przy `@Published`/`ObservableObject` dodaj `import Combine` (nowy Xcode ma ostrzejszy member-visibility).
- `navigationDestination requires Hashable` → modele nawigowane muszą być `Hashable` (enumy statusów też).
- `draggable/dropDestination requires Transferable` → samo `Codable` NIE wystarcza: dodać `Transferable` + jawnie `static var transferRepresentation: some TransferRepresentation { CodableRepresentation(contentType: .json) }` (+ `import CoreTransferable`, `UniformTypeIdentifiers`).
- `extension NazwaTypu` na poziomie pliku nie widzi typu zagnieżdżonego w struct — przenieś computed property do środka enuma zagnieżdżonego.
- Po refactorach: `Theme` nie ma już skasowanego koloru (`Theme.card` itp.) — sprawdzaj, czy kolor nadal istnieje w `Theme.swift`; po usuwaniu plików grepuj po nazwach (`SegmentedPicker`, `segmentActive`...), żeby nie zostały wiszące referencje.

**Zachowania platformy iOS 26/27 (sprawdzone praktyką):**
- Systemowy `Picker(.segmented)` pokazuje **ikonę LUB napis, nigdy oba** — decyzja PO: same napisy (własny segment ikona+napis był i odrzucony).
- `@Environment(\.editMode)` — zapisy z poziomu widoku działają zawodnie; **EditButton** psuł się („trzy kropki", dziwne przejścia). Działa niezawodnie: własne `@State isEditing` + zwykłe minus-przyciski w wierszach.
- Liquid Glass nad czarnym pustym tłem jest **niewidoczny** — szkło potrzebuje kolorowej treści pod sobą; PO odrzucił własne tła — chrom robią systemowe `TabView`/`.toolbar`, które mają szkło wbudowane.
- `.swipeActions` działa tylko na wierszach `List` (nie ScrollView) — stąd lista powiadomień to `List(.insetGrouped)` + `.scrollContentBackground(.hidden)`.
- Drag & drop workspace→grupa: `.draggable(model)` na wierszu + `.dropDestination(for:)` na nagłówku grupy + stan `hoveringTarget` na podświetlenie; usuwanie z grupy przez upuszczenie na kartę top-level lub context menu.
- Toast nad dolnym paskiem: `.overlay(alignment: .bottom)` na korzeniu + `.padding(.bottom, 76)` (nad systemowym pływającym tab barem); timer 2 s z anulowaniem poprzedniego Taska, żeby szybkich akcji nie migało.

**Wzorce ustalone z PO (pilnować):**
- Każda zmiana UI: tylko build, zero instalowania; PO testuje sam w Xcode.
- Nazewnictwo funkcji w kodzie po angielsku; copy UI wyłącznie amerykański angielski (PO: „zmień wszędzie napisy na amerykański angielski").
- Widok Agents = PRD `plans/umux-v2.0.0-prd.md` (#56, #128, #135): wiersz = chip statusu + folder + nazwa karty, sortowanie newest-signal-first, wiersze informacyjne (bez nawigacji — PO usunął), bez skrótu jump-to-unread (PO usunął), bez nagłówków sekcji WORKSPACES/AGENTS (PO usunął).
