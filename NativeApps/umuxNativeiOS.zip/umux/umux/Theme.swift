//
//  Theme.swift
//  umux
//
//  Colors, springs and press feedback shared by every screen.
//

import SwiftUI
import UIKit

enum Theme {
    // Surfaces
    static let background    = Color(hex: 0x050505)
    static let card          = Color(hex: 0x131315)
    static let separator     = Color(hex: 0x262628)

    // umux green
    static let accent        = Color(hex: 0x2F7D52)
    static let accentBright  = Color(hex: 0x45A26B)

    // Text
    static let textPrimary   = Color.white
    static let textSecondary = Color(hex: 0x9A9AA0)
    static let textTertiary  = Color(hex: 0x6C6C72)

    // Springs — critically damped by default; a touch of bounce on layout changes.
    static let press  = Animation.spring(response: 0.3, dampingFraction: 0.8)
    static let layout = Animation.spring(response: 0.35, dampingFraction: 0.85)
}

extension Color {
    init(hex: UInt, alpha: Double = 1) {
        self.init(
            .sRGB,
            red: Double((hex >> 16) & 0xFF) / 255,
            green: Double((hex >> 8) & 0xFF) / 255,
            blue: Double(hex & 0xFF) / 255,
            opacity: alpha
        )
    }
}

/// Hairline divider used between rows inside cards.
struct Separator: View {
    var body: some View {
        Rectangle()
            .fill(Theme.separator)
            .frame(height: 0.5)
            .padding(.horizontal, 16)
    }
}

/// Light haptic helpers — fire on the same frame as the visual change.
enum Haptics {
    static func tap() {
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
    }

    static func select() {
        UISelectionFeedbackGenerator().selectionChanged()
    }
}
