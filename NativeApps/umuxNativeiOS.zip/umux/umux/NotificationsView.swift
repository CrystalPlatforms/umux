//
//  NotificationsView.swift
//  umux
//
//  Screen 02: native toolbar (UMUX logo, Edit button), a standard segmented
//  filter and a native List — swipe a row left for [Mark Read/Mark Unread]
//  [Delete]. The Edit button toggles a plain isEditing state that shows
//  minus buttons on the rows (no system edit-mode machinery).
//

import SwiftUI

struct NotificationsView: View {
    @EnvironmentObject private var store: DataStore
    @State private var segment = 0
    @State private var isEditing = false
    @State private var detailPath: [UmuxNotification] = []

    private var visibleNotifications: [UmuxNotification] {
        segment == 1 ? store.notifications.filter(\.isUnread) : store.notifications
    }

    var body: some View {
        let visible = visibleNotifications

        VStack(spacing: 0) {
            Picker("Filter", selection: $segment) {
                Text("All").tag(0)
                Text("Unread").tag(1)
            }
            .pickerStyle(.segmented)
            .padding(.horizontal, 20)
            .padding(.top, 8)
            .padding(.bottom, 4)

            if visible.isEmpty {
                emptyState
            } else {
                notificationList(visible)
            }
        }
        .background(Theme.background)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .principal) {
                UmuxLogo(height: 40)
            }
            ToolbarItem(placement: .topBarTrailing) {
                Button(isEditing ? "Done" : "Edit") {
                    withAnimation { isEditing.toggle() }
                    Haptics.tap()
                }
            }
        }
        .navigationDestination(for: UmuxNotification.self) { notification in
            NotificationDetailView(notification: notification)
        }
    }

    // MARK: - List

    private func notificationList(_ items: [UmuxNotification]) -> some View {
        List {
            ForEach(items) { notification in
                row(notification)
                    .swipeActions(edge: .trailing, allowsFullSwipe: true) {
                        Button(role: .destructive) {
                            store.removeNotification(notification)
                        } label: {
                            Label("Delete", systemImage: "trash")
                        }

                        if notification.isUnread {
                            Button {
                                store.markRead(notification)
                            } label: {
                                Label("Mark Read", systemImage: "envelope.open")
                            }
                            .tint(Theme.accent)
                        } else {
                            Button {
                                store.markUnread(notification)
                            } label: {
                                Label("Mark Unread", systemImage: "envelope.badge")
                            }
                            .tint(.orange)
                        }
                    }
            }
        }
        .listStyle(.insetGrouped)
        .scrollContentBackground(.hidden)
        .background(Theme.background)
        .refreshable { await store.sync() }
    }

    private func row(_ notification: UmuxNotification) -> some View {
        HStack(spacing: 12) {
            if isEditing {
                Button {
                    store.removeNotification(notification)
                    Haptics.tap()
                } label: {
                    Image(systemName: "minus.circle.fill")
                        .font(.system(size: 22))
                        .foregroundStyle(.red)
                }
                .buttonStyle(.plain)
                .transition(.scale.combined(with: .opacity))
            }

            Button {
                guard !isEditing else { return }
                Haptics.tap()
                detailPath.append(notification)
            } label: {
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(notification.workspace)
                            .font(.system(size: 17, weight: .semibold))
                            .foregroundStyle(Theme.textPrimary)
                        Text(notification.message)
                            .font(.system(size: 15))
                            .foregroundStyle(Theme.textSecondary)
                    }
                    Spacer()
                    if notification.isUnread {
                        Circle()
                            .fill(Theme.accentBright)
                            .frame(width: 7, height: 7)
                    }
                    Image(systemName: "chevron.right")
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundStyle(Theme.textTertiary)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
        }
        .padding(.leading, isEditing ? 12 : 16)
        .padding(.trailing, 16)
    }

    // MARK: - Empty state

    private var emptyState: some View {
        VStack(spacing: 10) {
            Image(systemName: "bell.slash")
                .font(.system(size: 30))
                .foregroundStyle(Theme.textTertiary)
            Text("You're all caught up")
                .font(.system(size: 15, weight: .medium))
                .foregroundStyle(Theme.textSecondary)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

#Preview {
    NavigationStack {
        NotificationsView()
    }
    .environmentObject(DataStore())
    .preferredColorScheme(.dark)
}
