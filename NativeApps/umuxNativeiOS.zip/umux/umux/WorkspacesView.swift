//
//  WorkspacesView.swift
//  umux
//
//  Screen 01: workspace management mirroring umux Desktop —
//  the "+" unfolds New workspace / New group, groups collapse and
//  accept dragged workspaces, rows rename and delete via context menu.
//

import SwiftUI

struct WorkspacesView: View {
    @EnvironmentObject private var store: DataStore
    @State private var segment = 0
    @State private var detailPath: [Workspace] = []
    @State private var collapsedGroups: Set<UUID> = []
    @State private var renameTarget: RenameTarget?
    @State private var renameText = ""
    @State private var selectedInstance = "Instance 1"

    enum RenameTarget: Identifiable {
        case workspace(Workspace)
        case group(WorkspaceGroup)

        var id: UUID {
            switch self {
            case .workspace(let workspace): return workspace.id
            case .group(let group):         return group.id
            }
        }

        var message: String {
            switch self {
            case .workspace: return "Enter the new workspace name."
            case .group:     return "Enter the new group name."
            }
        }
    }

    /// Top-level (ungrouped) workspaces in store order.
    private var topWorkspaces: [Workspace] {
        store.workspaces.filter { $0.groupID == nil }
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Picker("Filter", selection: $segment) {
                    Text("Local").tag(0)
                    Text("Agents").tag(1)
                    Text("SSH").tag(2)
                }
                .pickerStyle(.segmented)

                content
            }
            .padding(.horizontal, 20)
            .padding(.top, 8)
            .padding(.bottom, 24)
        }
        .background(Theme.background)
        .refreshable { await store.sync() }
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                Menu {
                    Picker("Instance", selection: $selectedInstance) {
                        Text("Instance 1").tag("Instance 1")
                        Text("Instance 2").tag("Instance 2")
                    }
                } label: {
                    Image(systemName: "rectangle.on.rectangle.angled")
                }
                .accessibilityLabel("Instances")
            }
            ToolbarItem(placement: .principal) {
                UmuxLogo(height: 40)
            }
            ToolbarItem(placement: .topBarTrailing) {
                deviceMenu
            }
            ToolbarItem(placement: .topBarTrailing) {
                addButton
            }
        }
        .navigationDestination(for: Workspace.self) { workspace in
            WorkspaceDetailView(workspace: workspace)
        }
        .alert(
            "Rename",
            isPresented: Binding(
                get: { renameTarget != nil },
                set: { if !$0 { renameTarget = nil } }
            ),
            presenting: renameTarget
        ) { target in
            TextField("Name", text: $renameText)
            Button("Cancel", role: .cancel) {}
            Button("Save") { commitRename(target) }
        } message: { target in
            Text(target.message)
        }
    }

    // MARK: - Content per segment

    @ViewBuilder
    private var content: some View {
        switch segment {
        case 1:
            agentsView
        case 2:
            emptyState(icon: "network", title: "No SSH machines",
                       subtitle: "")
        default:
            if topWorkspaces.isEmpty && store.groups.isEmpty {
                emptyState(icon: "widget.medium", title: "No layout",
                           subtitle: "")
            } else {
                localList
            }
        }
    }

    /// The Local tree: a card of top-level workspaces + one card per group.
    private var localList: some View {
        VStack(alignment: .leading, spacing: 14) {
            if !topWorkspaces.isEmpty {
                VStack(spacing: 0) {
                    ForEach(topWorkspaces) { workspace in
                        if workspace.id != topWorkspaces.first?.id {
                            Separator()
                        }
                        workspaceRow(workspace, grouped: false)
                    }
                }
                .background(cardShape)
                .dropDestination(for: Workspace.self) { payloads, _ in
                    // Dropping on the top-level card pulls the workspace out of its group.
                    guard let workspace = payloads.first else { return false }
                    store.removeFromGroup(workspace)
                    return true
                } isTargeted: { _ in }
            }

            ForEach(store.groups) { group in
                groupCard(group)
            }
        }
    }

    private func groupCard(_ group: WorkspaceGroup) -> some View {
        let members = store.workspaces.filter { $0.groupID == group.id }
        let isCollapsed = collapsedGroups.contains(group.id)

        return VStack(spacing: 0) {
            Button {
                withAnimation(Theme.layout) {
                    if isCollapsed {
                        collapsedGroups.remove(group.id)
                    } else {
                        collapsedGroups.insert(group.id)
                    }
                }
                Haptics.select()
            } label: {
                HStack(spacing: 8) {
                    Image(systemName: isCollapsed ? "folder.fill" : "folder")
                        .font(.system(size: 15))
                        .foregroundStyle(Theme.accentBright)
                    Text(group.name)
                        .font(.system(size: 17, weight: .semibold))
                        .foregroundStyle(Theme.textPrimary)
                    Text("\(members.count)")
                        .font(.system(size: 13))
                        .foregroundStyle(Theme.textTertiary)
                    Spacer()
                    Image(systemName: "chevron.down")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundStyle(Theme.textTertiary)
                        .rotationEffect(.degrees(isCollapsed ? -90 : 0))
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 14)
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .contextMenu {
                renameButton(for: .group(group))
                deleteButton { store.removeGroup(group.id) }
            }
            .dropDestination(for: Workspace.self) { payloads, _ in
                guard let workspace = payloads.first else { return false }
                store.assign(workspace, toGroup: group.id)
                Haptics.tap()
                return true
            } isTargeted: { hovering in
                hoveringTarget = hovering ? group.id : nil
            }
            .overlay(
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .stroke(Theme.accentBright, lineWidth: 1.5)
                    .opacity(hoveringTarget == group.id ? 1 : 0)
            )

            if !isCollapsed && !members.isEmpty {
                ForEach(members) { workspace in
                    Separator()
                    workspaceRow(workspace, grouped: true)
                }
            }
        }
        .background(cardShape)
    }

    private func workspaceRow(_ workspace: Workspace, grouped: Bool) -> some View {
        Button {
            Haptics.tap()
            store.markAgentViewed(workspace.id)
            detailPath.append(workspace)
        } label: {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text(workspace.name)
                        .font(.system(size: 17, weight: .semibold))
                        .foregroundStyle(Theme.textPrimary)
                    HStack(spacing: 7) {
                        Circle()
                            .fill(workspace.status.color)
                            .frame(width: 8, height: 8)
                        Text(workspace.status.label)
                            .font(.system(size: 15))
                            .foregroundStyle(Theme.textSecondary)
                    }
                }
                Spacer()
                if store.isUnread(workspace) {
                    Circle()
                        .fill(Theme.accentBright)
                        .frame(width: 7, height: 7)
                }
                Image(systemName: "chevron.right")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(Theme.textTertiary)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 14)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .draggable(workspace)
        .contextMenu {
            renameButton(for: .workspace(workspace))
            if grouped {
                Button {
                    store.removeFromGroup(workspace)
                } label: {
                    Label("Remove from group", systemImage: "folder.badge.minus")
                }
            }
            deleteButton { store.removeWorkspace(workspace.id) }
        }
    }

    /// Flat card of workspaces (Agents segment).
    private func flatList(_ workspaces: [Workspace]) -> some View {
        VStack(spacing: 0) {
            ForEach(workspaces) { workspace in
                if workspace.id != workspaces.first?.id {
                    Separator()
                }
                workspaceRow(workspace, grouped: false)
            }
        }
        .background(cardShape)
    }

    // MARK: - Agents View (PRD #128, #56, #135)

    /// Full Agents view (separate-tab placement, PRD #135): every running
    /// agent as chip + folder + tab name, newest signal first. Rows are
    /// informational — no navigation.
    private var agentsView: some View {
        let runs = store.agentRuns()

        return VStack(alignment: .leading, spacing: 14) {
            if runs.isEmpty {
                emptyState(icon: "person.2", title: "No agents",
                           subtitle: "")
            } else {
                VStack(spacing: 0) {
                    ForEach(runs) { run in
                        if run.id != runs.first?.id {
                            Separator()
                        }
                        agentRow(run)
                    }
                }
                .background(cardShape)
            }
        }
    }

    private func agentRow(_ run: AgentRun) -> some View {
        HStack(spacing: 10) {
            // Agent-status chip (PRD #128).
            HStack(spacing: 5) {
                Circle()
                    .fill(run.status.color)
                    .frame(width: 6, height: 6)
                Text(run.status.shortLabel)
                    .font(.system(size: 11, weight: .semibold))
            }
            .foregroundStyle(run.status.color)
            .padding(.horizontal, 8)
            .padding(.vertical, 4)
            .background(
                Capsule().fill(run.status.color.opacity(0.15))
            )

            VStack(alignment: .leading, spacing: 3) {
                Text(run.tabName)
                    .font(.system(size: 17, weight: .semibold))
                    .foregroundStyle(Theme.textPrimary)
                Text("\(run.folder) · \(run.workspaceName)")
                    .font(.system(size: 14))
                    .foregroundStyle(Theme.textSecondary)
                    .lineLimit(1)
            }
            Spacer()
            if run.isUnread {
                Circle()
                    .fill(Theme.accentBright)
                    .frame(width: 7, height: 7)
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 13)
    }

    // MARK: - Toolbar

    private var deviceMenu: some View {
        Menu {
            Picker("Device", selection: $store.selectedDevice) {
                ForEach(store.devices, id: \.self) { device in
                    Text(device).tag(device)
                }
            }
        } label: {
            Label("Device", systemImage: "display.2")
        }
    }

    /// ONE button that unfolds the choice — like the desktop header "+".
    private var addButton: some View {
        Menu {
            Button {
                store.addWorkspace()
                Haptics.tap()
            } label: {
                Label("New workspace", systemImage: "rectangle.dashed")
            }
            Button {
                store.addGroup()
                Haptics.tap()
            } label: {
                Label("New group", systemImage: "folder")
            }
        } label: {
            Image(systemName: "plus")
        }
        .accessibilityLabel("Add workspace or group")
    }

    // MARK: - Rename / delete helpers

    @State private var hoveringTarget: UUID?

    private func renameButton(for target: RenameTarget) -> some View {
        Button {
            switch target {
            case .workspace(let workspace):
                renameText = workspace.name
            case .group(let group):
                renameText = group.name
            }
            renameTarget = target
        } label: {
            Label("Rename", systemImage: "pencil")
        }
    }

    private func deleteButton(action: @escaping () -> Void) -> some View {
        Button(role: .destructive, action: action) {
            Label("Delete", systemImage: "trash")
        }
    }

    private func commitRename(_ target: RenameTarget) {
        let name = renameText.trimmingCharacters(in: .whitespaces)
        guard !name.isEmpty else { return }
        switch target {
        case .workspace(let workspace):
            store.renameWorkspace(workspace.id, to: name)
        case .group(let group):
            store.renameGroup(group.id, to: name)
        }
        Haptics.tap()
    }

    private func emptyState(icon: String, title: String, subtitle: String) -> some View {
        VStack(spacing: 10) {
            Image(systemName: icon)
                .font(.system(size: 30))
                .foregroundStyle(Theme.textTertiary)
            Text(title)
                .font(.system(size: 15, weight: .medium))
                .foregroundStyle(Theme.textSecondary)
            Text(subtitle)
                .font(.system(size: 13))
                .foregroundStyle(Theme.textTertiary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 48)
    }
}

private extension View {
    var cardShape: some View {
        RoundedRectangle(cornerRadius: 14, style: .continuous)
            .fill(Theme.card)
    }
}

#Preview {
    NavigationStack {
        WorkspacesView()
    }
    .environmentObject(DataStore())
    .preferredColorScheme(.dark)
}
