//
//  SplashView.swift
//  umux
//
//  Cold-start sequence: system launch screen shows the pre-rendered
//  "umux by Crystal" text the moment the icon is tapped, then this
//  in-app splash continues with the same text + loader, and fades
//  into Home. No images, text only.
//

import SwiftUI

struct SplashView: View {
    var body: some View {
        ZStack {
            Theme.background.ignoresSafeArea()
            VStack(spacing: 28) {
                Text("umux by Crystal")
                    .font(.system(size: 26, weight: .semibold))
                    .foregroundStyle(Theme.textPrimary)
                ProgressView()
                    .tint(Theme.accentBright)
            }
        }
    }
}

#Preview {
    SplashView()
}
