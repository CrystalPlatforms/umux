//
//  umuxApp.swift
//  umux
//
//  Created by Adam on 9/12/26.
//

import SwiftUI

@main
struct umuxApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
