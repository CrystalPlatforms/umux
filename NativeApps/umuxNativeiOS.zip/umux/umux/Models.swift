//
//  Models.swift
//  umux
//
//  Demo data matching the PWA mockup + a small store that survives tab switches.
//

import SwiftUI
import Combine
import CoreTransferable
import UniformTypeIdentifiers

enum AgentStatus: Codable, Hashable {
    case working
    case needsAttention
    case idle

    var label: String {
        switch self {
        case .working:        return "Agent working"
        case .needsAttention: return "Needs attention"
        case .idle:           return "Idle"
        }
    }

    /// Short form for the Agents View chip (PRD #128).
    var shortLabel: String {
        switch self {
        case .working:        return "Working"
        case .needsAttention: return "Waiting"
        case .idle:           return "Idle"
        }
    }

    var color: Color {
        switch self {
        case .working:        return Color(hex: 0xE5A54B)
        case .needsAttention: return Color(hex: 0x4D8DF7)
        case .idle:           return Color(hex: 0x98989D)
        }
    }
}

struct Workspace: Identifiable, Hashable, Codable, Transferable {
    let id: UUID
    var name: String
    var status: AgentStatus
    /// Parent group (like `groupId` in umux Desktop). nil = top level.
    var groupID: UUID?

    init(name: String, status: AgentStatus, groupID: UUID? = nil) {
        self.id = UUID()
        self.name = name
        self.status = status
        self.groupID = groupID
    }

    /// Payload for drag & drop (JSON via Codable).
    static var transferRepresentation: some TransferRepresentation {
        CodableRepresentation(contentType: .json)
    }
}

/// A named container workspaces can be filed into (like groups in
/// umux Desktop, #48). Flat for now — the desktop's nested tree can come later.
struct WorkspaceGroup: Identifiable, Hashable, Codable {
    let id: UUID
    var name: String

    init(name: String) {
        self.id = UUID()
        self.name = name
    }
}

/// One running agent as shown in the Agents View (PRD #128):
/// status chip + folder + tab name, newest signal first.
struct AgentRun: Identifiable, Hashable {
    let id: UUID
    var workspaceName: String
    var tabName: String
    var folder: String
    var status: AgentStatus
    var lastSignalAt: Date
    /// Finished/waiting and not viewed yet (unread marker, PRD #56).
    var isUnread: Bool
}

struct UmuxNotification: Identifiable, Hashable {
    let id = UUID()
    var workspace: String
    var message: String
    var isUnread: Bool
}

/// Holds the demo lists so they survive switching between bottom tabs.
@MainActor
final class DataStore: ObservableObject {
    @Published var workspaces: [Workspace] = [
        Workspace(name: "umux",            status: .working),
        Workspace(name: "auditmos",        status: .needsAttention),
        Workspace(name: "Test workspace",  status: .idle),
        Workspace(name: "Test workspace 2", status: .idle),
    ]

    @Published var notifications: [UmuxNotification] = {
        // The mockup alternates the two test workspaces after the first two rows.
        var items: [UmuxNotification] = [
            UmuxNotification(workspace: "umux",     message: "Test notification",   isUnread: true),
            UmuxNotification(workspace: "auditmos", message: "Test notification 2", isUnread: true),
        ]
        for n in 3...15 {
            let workspace = n % 2 == 1 ? "Test workspace" : "Test workspace 2"
            items.append(
                UmuxNotification(
                    workspace: workspace,
                    message: "Test notification \(n)",
                    isUnread: n <= 4
                )
            )
        }
        return items
    }()

    // Paired machines (umux Bridge, mock).
    let devices = ["MacBook Pro", "Ubuntu Dev", "ThinkPad"]
    @Published var selectedDevice = "MacBook Pro"

    @Published var groups: [WorkspaceGroup] = []

    // Sync toast — shown over the bottom bar after every workspace/group
    // create, rename or delete.
    @Published var showSyncToast = false
    private var syncToastTask: Task<Void, Never>?

    /// Shows the "Syncing..." toast for 2 seconds, restarting the
    /// timer if another change lands mid-toast.
    private func flashSyncToast() {
        syncToastTask?.cancel()
        showSyncToast = true
        syncToastTask = Task { [weak self] in
            try? await Task.sleep(for: .seconds(2))
            guard !Task.isCancelled else { return }
            self?.showSyncToast = false
        }
    }

    // MARK: Agents View (PRD #128–#129, #56)

    /// Mock of the OSC-derived per-agent metadata (tab name, folder,
    /// most recent signal time).
    struct AgentMeta {
        let tab: String
        let folder: String
        let signalAt: Date
    }

    private var agentMeta: [UUID: AgentMeta] = [:]

    /// Unread markers (PRD #56): a waiting/finished agent stays unread
    /// until its panel is viewed. In the prototype "viewing the panel"
    /// means opening the workspace detail.
    @Published private(set) var viewedAgents: Set<UUID> = []

    init() {
        let now = Date()
        for workspace in workspaces {
            switch workspace.name {
            case "umux":
                agentMeta[workspace.id] = AgentMeta(
                    tab: "claude", folder: "Documents/umux",
                    signalAt: now.addingTimeInterval(-2 * 60)
                )
            case "auditmos":
                agentMeta[workspace.id] = AgentMeta(
                    tab: "codex", folder: "Documents/auditmos",
                    signalAt: now.addingTimeInterval(-14 * 60)
                )
            default:
                break
            }
        }
    }

    /// Every running agent, newest signal first (PRD #128).
    func agentRuns() -> [AgentRun] {
        workspaces
            .filter { $0.status != .idle }
            .map { workspace in
                let meta = agentMeta[workspace.id]
                return AgentRun(
                    id: workspace.id,
                    workspaceName: workspace.name,
                    tabName: meta?.tab ?? "agent",
                    folder: meta?.folder ?? "—",
                    status: workspace.status,
                    lastSignalAt: meta?.signalAt ?? .distantPast,
                    isUnread: isUnread(workspace)
                )
            }
            .sorted { $0.lastSignalAt > $1.lastSignalAt }
    }

    /// Unread = finished/waiting and not viewed yet (PRD #56).
    func isUnread(_ workspace: Workspace) -> Bool {
        workspace.status == .needsAttention && !viewedAgents.contains(workspace.id)
    }

    /// Clears the unread marker (PRD #56: cleared on viewing the panel).
    func markAgentViewed(_ workspaceID: UUID) {
        viewedAgents.insert(workspaceID)
    }

    private var newWorkspaceCount = 0
    private var newGroupCount = 0

    func addWorkspace() {
        newWorkspaceCount += 1
        workspaces.append(
            Workspace(name: "New workspace \(newWorkspaceCount)", status: .idle)
        )
        flashSyncToast()
    }

    func addGroup() {
        newGroupCount += 1
        groups.append(WorkspaceGroup(name: "New group \(newGroupCount)"))
        flashSyncToast()
    }

    func renameWorkspace(_ id: UUID, to name: String) {
        guard let index = workspaces.firstIndex(where: { $0.id == id }) else { return }
        workspaces[index].name = name
        flashSyncToast()
    }

    func renameGroup(_ id: UUID, to name: String) {
        guard let index = groups.firstIndex(where: { $0.id == id }) else { return }
        groups[index].name = name
        flashSyncToast()
    }

    func removeWorkspace(_ id: UUID) {
        workspaces.removeAll { $0.id == id }
        flashSyncToast()
    }

    /// Deleting a group leaves its workspaces — they just become ungrouped
    /// (like the desktop's plain group delete).
    func removeGroup(_ id: UUID) {
        groups.removeAll { $0.id == id }
        for index in workspaces.indices where workspaces[index].groupID == id {
            workspaces[index].groupID = nil
        }
        flashSyncToast()
    }

    /// Drag & drop: file a workspace into a group.
    func assign(_ workspace: Workspace, toGroup groupID: UUID) {
        guard let index = workspaces.firstIndex(where: { $0.id == workspace.id }) else { return }
        workspaces[index].groupID = groupID
    }

    /// Drag & drop / context menu: pull a workspace back to the top level.
    func removeFromGroup(_ workspace: Workspace) {
        guard let index = workspaces.firstIndex(where: { $0.id == workspace.id }) else { return }
        workspaces[index].groupID = nil
    }

    func removeNotification(_ notification: UmuxNotification) {
        notifications.removeAll { $0.id == notification.id }
    }

    /// Removes by id — used by the List's onDelete (indices of a filtered view).
    func removeNotifications(withIDs ids: [UUID]) {
        notifications.removeAll { ids.contains($0.id) }
    }

    /// Swipe action: mark a notification as read.
    func markRead(_ notification: UmuxNotification) {
        if let index = notifications.firstIndex(where: { $0.id == notification.id }) {
            notifications[index].isUnread = false
        }
    }

    /// Swipe action: mark a read notification as unread again.
    func markUnread(_ notification: UmuxNotification) {
        if let index = notifications.firstIndex(where: { $0.id == notification.id }) {
            notifications[index].isUnread = true
        }
    }
}
