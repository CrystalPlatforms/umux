//
//  UmuxLogo.swift
//  umux
//
//  The official UMUX dot-matrix wordmark (white, transparent PNG).
//

import SwiftUI

struct UmuxLogo: View {
    var height: CGFloat = 28

    var body: some View {
        Image("UmuxLogo")
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(height: height)
            .accessibilityLabel("UMUX")
    }
}

#Preview {
    UmuxLogo()
        .padding(40)
        .background(Color.black)
}
