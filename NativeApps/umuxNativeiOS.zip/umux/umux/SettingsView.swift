//
//  SettingsView.swift
//  umux
//
//  Third tab. Real settings (sign-in, paired devices) arrive with
//  the umux Ecosystem (PRD #115, #123).
//

import SwiftUI

struct SettingsView: View {
    @State private var showComingSoon = false

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                VStack(spacing: 0) {
                    signInRow(
                        title: "Continue with Google",
                        icon: { Image("GoogleLogo").resizable().scaledToFit().frame(width: 19, height: 19) }
                    )
                    Separator()
                    signInRow(
                        title: "Continue with GitHub",
                        icon: { Image("GitHubLogo").resizable().scaledToFit().frame(width: 20, height: 20).foregroundStyle(.white) }
                    )
                    Separator()
                    signInRow(
                        title: "Continue with Apple",
                        icon: { Image(systemName: "apple.logo").font(.system(size: 19)).foregroundStyle(.white) }
                    )
                }
                .background(
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .fill(Theme.card)
                )

                infoRow(title: "Paired devices", value: "umux Bridge — soon")
                infoRow(title: "Push notifications", value: "umux Bridge — soon")

                Text("umux PWA prototype · demo data only")
                    .font(.system(size: 12))
                    .foregroundStyle(Theme.textTertiary)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .padding(.top, 24)
            }
            .padding(.horizontal, 20)
            .padding(.top, 8)
            .padding(.bottom, 24)
        }
        .navigationTitle("Settings")
        .navigationBarTitleDisplayMode(.large)
        .alert("Coming soon", isPresented: $showComingSoon) {
            Button("OK", role: .cancel) {}
        } message: {
            Text("Sign-in ships with the umux Ecosystem.")
        }
    }

    private func signInRow<Icon: View>(
        title: String,
        @ViewBuilder icon: () -> Icon
    ) -> some View {
        Button {
            Haptics.tap()
            showComingSoon = true
        } label: {
            HStack(spacing: 10) {
                icon()
                Text(title)
                    .font(.system(size: 16, weight: .medium))
                    .foregroundStyle(Theme.textPrimary)
                Spacer()
                Image(systemName: "chevron.right")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(Theme.textTertiary)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 15)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }

    private func infoRow(title: String, value: String) -> some View {
        HStack {
            Text(title)
                .font(.system(size: 16))
                .foregroundStyle(Theme.textSecondary)
            Spacer()
            Text(value)
                .font(.system(size: 14))
                .foregroundStyle(Theme.textTertiary)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 13)
        .background(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .fill(Theme.card)
        )
    }
}

#Preview {
    NavigationStack {
        SettingsView()
    }
    .preferredColorScheme(.dark)
}
