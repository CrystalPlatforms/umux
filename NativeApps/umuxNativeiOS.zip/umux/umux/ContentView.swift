//
//  ContentView.swift
//  umux
//
//  Root: a native TabView — iOS 26 renders the floating Liquid Glass
//  tab bar itself. Each tab owns a NavigationStack with a standard
//  toolbar (its buttons get the official glass treatment too).
//

import SwiftUI

enum HomeTab: Hashable {
    case home
    case notifications
    case settings
}

struct ContentView: View {
    @StateObject private var store = DataStore()
    @State private var tab: HomeTab = .home
    @State private var isSplashVisible = true

    var body: some View {
        TabView(selection: $tab) {
            NavigationStack {
                WorkspacesView()
            }
            .tabItem { Label("Home", systemImage: "house.lodge.fill") }
            .tag(HomeTab.home)

            NavigationStack {
                NotificationsView()
            }
            .tabItem { Label("Notifications", systemImage: "bell.fill") }
            .tag(HomeTab.notifications)

            NavigationStack {
                SettingsView()
            }
            .tabItem { Label("Settings", systemImage: "gearshape.fill") }
            .tag(HomeTab.settings)
        }
        .overlay {
            if isSplashVisible {
                SplashView()
                    .transition(.opacity)
                    .zIndex(1)
            }
        }
        .task {
            // Icon + loader on cold start, then fade into Home.
            try? await Task.sleep(for: .seconds(1.0))
            withAnimation(.easeOut(duration: 0.35)) {
                isSplashVisible = false
            }
        }
        .overlay(alignment: .bottom) {
            if store.showSyncToast {
                HStack(spacing: 8) {
                    ProgressView()
                        .tint(Theme.textSecondary)
                    Text("Syncing...")
                        .font(.system(size: 14, weight: .medium))
                        .foregroundStyle(Theme.textPrimary)
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 10)
                .background(
                    Capsule()
                        .fill(Theme.card)
                        .shadow(color: .black.opacity(0.4), radius: 12, y: 4)
                )
                .padding(.bottom, 76)
                .transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
        .animation(Theme.layout, value: store.showSyncToast)
        .environmentObject(store)
        .preferredColorScheme(.dark)
    }
}

#Preview {
    ContentView()
}
