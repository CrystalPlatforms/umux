//
//  ItemDetails.swift
//  umux
//
//  Placeholder detail screens with the standard navigation bar —
//  the system back button and title come for free. The real read-only
//  output and "message the agent" flow ship with the umux Ecosystem
//  (PRD #117, #119).
//

import SwiftUI

struct WorkspaceDetailView: View {
    let workspace: Workspace

    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            HStack(spacing: 8) {
                Circle()
                    .fill(workspace.status.color)
                    .frame(width: 9, height: 9)
                Text(workspace.status.label)
                    .font(.system(size: 15, weight: .medium))
                    .foregroundStyle(Theme.textSecondary)
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 9)
            .background(
                Capsule().fill(Theme.card)
            )

            placeholderCard(
                icon: "terminal",
                text: "The read-only agent output will stream here once umux Bridge is connected."
            )

            Spacer()
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.horizontal, 20)
        .padding(.top, 6)
        .navigationTitle(workspace.name)
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct NotificationDetailView: View {
    let notification: UmuxNotification

    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            VStack(alignment: .leading, spacing: 6) {
                Text("MESSAGE")
                    .font(.system(size: 11, weight: .semibold))
                    .tracking(1)
                    .foregroundStyle(Theme.textTertiary)
                Text(notification.message)
                    .font(.system(size: 17))
                    .foregroundStyle(Theme.textPrimary)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(16)
            .background(
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .fill(Theme.card)
            )

            placeholderCard(
                icon: "terminal",
                text: "Tap through to the agent panel here once umux Bridge is connected."
            )

            Spacer()
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.horizontal, 20)
        .padding(.top, 6)
        .navigationTitle(notification.workspace)
        .navigationBarTitleDisplayMode(.inline)
    }
}

private func placeholderCard(icon: String, text: String) -> some View {
    VStack(spacing: 12) {
        Image(systemName: icon)
            .font(.system(size: 26))
            .foregroundStyle(Theme.textTertiary)
        Text(text)
            .font(.system(size: 14))
            .foregroundStyle(Theme.textSecondary)
            .multilineTextAlignment(.center)
    }
    .frame(maxWidth: .infinity)
    .padding(.vertical, 32)
    .padding(.horizontal, 20)
    .background(
        RoundedRectangle(cornerRadius: 14, style: .continuous)
            .fill(Theme.card)
    )
}

#Preview {
    NavigationStack {
        WorkspaceDetailView(workspace: Workspace(name: "umux", status: .working))
    }
    .preferredColorScheme(.dark)
}
